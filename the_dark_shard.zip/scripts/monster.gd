extends Node3D
# Monster: patroli acak -> mengejar kalau melihat/mendengar pemain -> kehilangan jejak.

const Ent = preload("res://scripts/entities.gd")
const DIRS = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var game
var maze
var visual: Node3D
var marker: MeshInstance3D
var overlay: StandardMaterial3D
var limbs: Array = []
var bob := false
var anim_player: AnimationPlayer = null
var chase_speed := 4.0
var patrol_speed := 2.0
var sight := 16.0
var state := 0          # 0 patroli, 1 mengejar
var stun_t := 0.0
var cur_tile := Vector2i.ZERO
var next_tile := Vector2i.ZERO
var prev_tile := Vector2i(-1, -1)
var spawn_tile := Vector2i.ZERO
var think_t := 0.0
var los := false
var lose_t := 0.0
var walk_t := 0.0
var direct := false


func setup(g, mz, tile: Vector2i, ent: Dictionary, lvd: Dictionary, idx: int) -> void:
	game = g
	maze = mz
	spawn_tile = tile
	cur_tile = tile
	next_tile = tile
	position = maze.center_of(tile)
	chase_speed = float(lvd.chase) * (0.94 + 0.06 * float(idx % 3))
	patrol_speed = float(lvd.patrol)
	sight = float(lvd.sight)
	visual = Node3D.new()
	add_child(visual)
	var body: Color = lvd.body
	var eye: Color = lvd.eye
	var built := false
	if int(ent.m) > 0:
		built = _load_model(int(ent.m), eye)
	if not built:
		var v: Node3D = Ent.build(int(ent.k), body, eye)
		visual.add_child(v)
		limbs = v.get_meta("limbs")
		bob = v.get_meta("bob")
	var lt := OmniLight3D.new()
	lt.position = Vector3(0, 1.6, 0)
	lt.omni_range = 5.5
	lt.light_energy = 0.8
	lt.light_color = eye
	add_child(lt)
	# penanda untuk skill Detector (tembus tembok)
	var mk := StandardMaterial3D.new()
	mk.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mk.albedo_color = Color(1.0, 0.1, 0.1)
	mk.no_depth_test = true
	mk.disable_fog = true
	marker = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.4
	sm.height = 0.8
	marker.mesh = sm
	marker.material_override = mk
	marker.position = Vector3(0, 3.6, 0)
	marker.visible = false
	add_child(marker)
	overlay = StandardMaterial3D.new()
	overlay.albedo_color = Color(0.3, 0.8, 1.0, 0.55)
	overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	overlay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func _load_model(n: int, glow_col: Color) -> bool:
	var path := "res://assets/models/entity_%d.glb" % n
	if not ResourceLoader.exists(path):
		return false
	var ps = load(path)
	if ps == null or not (ps is PackedScene):
		return false
	var inst = ps.instantiate()
	if not (inst is Node3D):
		inst.queue_free()
		return false
	visual.add_child(inst)
	var height := 1.4 if n == 1 else 2.4
	var box: AABB = _aabb(inst)
	if box.size.y > 0.0001:
		var sc: float = height / box.size.y
		inst.scale = Vector3.ONE * sc
		inst.position = Vector3(-(box.position.x + box.size.x * 0.5) * sc, -box.position.y * sc, -(box.position.z + box.size.z * 0.5) * sc)
	_tint(inst, Color(0.2, 0.2, 0.25), glow_col)
	var aps = inst.find_children("*", "AnimationPlayer", true, false)
	if aps.size() > 0:
		anim_player = aps[0]
		var pick := ""
		for nm in anim_player.get_animation_list():
			var l := String(nm).to_lower()
			if l.find("run") >= 0:
				pick = String(nm)
				break
			if l.find("walk") >= 0 and pick == "":
				pick = String(nm)
		if pick == "":
			for nm in anim_player.get_animation_list():
				if String(nm) != "RESET":
					pick = String(nm)
					break
		if pick != "":
			anim_player.get_animation(pick).loop_mode = Animation.LOOP_LINEAR
			anim_player.play(pick)
	return true


func _aabb(root: Node3D) -> AABB:
	var inv: Transform3D = root.global_transform.affine_inverse()
	var box := AABB()
	var first := true
	for mi in root.find_children("*", "MeshInstance3D", true, false):
		var a: AABB = (inv * mi.global_transform) * mi.get_aabb()
		if first:
			box = a
			first = false
		else:
			box = box.merge(a)
	return box


func _tint(root: Node, tint: Color, glow_col: Color) -> void:
	for mi in root.find_children("*", "MeshInstance3D", true, false):
		if mi.mesh == null:
			continue
		for i in mi.mesh.get_surface_count():
			var m = mi.get_active_material(i)
			if m is StandardMaterial3D:
				var d: StandardMaterial3D = m.duplicate()
				d.albedo_color = d.albedo_color * tint
				d.emission_enabled = true
				d.emission = glow_col
				d.emission_energy_multiplier = 0.25
				mi.set_surface_override_material(i, d)


func reset() -> void:
	position = maze.center_of(spawn_tile)
	cur_tile = spawn_tile
	next_tile = spawn_tile
	state = 0
	lose_t = 0.0
	stun_t = 0.0
	direct = false
	_stun_visual(false)


func stun(t: float) -> void:
	stun_t = t
	state = 0
	_stun_visual(true)


func set_reveal(v: bool) -> void:
	marker.visible = v


func _stun_visual(on: bool) -> void:
	for mi in visual.find_children("*", "MeshInstance3D", true, false):
		mi.material_overlay = overlay if on else null
	if anim_player != null and on:
		anim_player.speed_scale = 0.0


func _process(delta: float) -> void:
	if game == null or game.frozen:
		return
	if stun_t > 0.0:
		stun_t -= delta
		if stun_t <= 0.0:
			_stun_visual(false)
		return
	_ai(delta)
	_animate(delta)


func _tile_here() -> Vector2i:
	return maze.tile_of(position)


func _ai(delta: float) -> void:
	var pp: Vector3 = game.player_pos
	var d: float = Vector2(pp.x - position.x, pp.z - position.z).length()
	think_t -= delta
	if think_t <= 0.0:
		think_t = 0.15
		los = false
		if not game.player_hidden and d < sight:
			los = _line_clear(pp)
		var pd: int = game.dist_at(_tile_here())
		var seen: bool = (los or (pd >= 0 and pd <= 5)) and not game.player_hidden
		if state == 0 and seen:
			state = 1
			lose_t = 0.0
			game.on_monster_alert(self)
		elif state == 1:
			if seen or (pd >= 0 and pd <= 14 and not game.player_hidden):
				lose_t = 0.0
			else:
				lose_t += 0.15
				if lose_t > 4.0:
					state = 0
		if game.player_hidden:
			state = 0
	var spd: float = patrol_speed if state == 0 else chase_speed
	if state == 1 and los and d < 12.0 and d > 0.05:
		# lurus ke pemain saat terlihat jelas
		var dv := Vector3(pp.x - position.x, 0.0, pp.z - position.z)
		var np: Vector3 = position + dv.normalized() * spd * delta
		if not maze.solid_world(np.x, np.z):
			_face(dv, delta)
			position = np
		direct = true
		cur_tile = _tile_here()
		next_tile = cur_tile
		return
	if direct:
		direct = false
		cur_tile = _tile_here()
		next_tile = cur_tile
	var tgt: Vector3 = maze.center_of(next_tile)
	var to := Vector3(tgt.x - position.x, 0.0, tgt.z - position.z)
	var dist_left: float = to.length()
	var step: float = spd * delta
	if dist_left <= step + 0.02:
		position.x = tgt.x
		position.z = tgt.z
		cur_tile = next_tile
		next_tile = _choose_next()
	else:
		_face(to, delta)
		position += to / dist_left * step


func _choose_next() -> Vector2i:
	var opts: Array = []
	for dd in DIRS:
		var n: Vector2i = cur_tile + dd
		if not maze.solid_tile(n.x, n.y):
			opts.append(n)
	if opts.is_empty():
		return cur_tile
	if state == 1:
		var cd: int = game.dist_at(cur_tile)
		var best: Vector2i = cur_tile
		var bd := 1000000
		for n in opts:
			var nd: int = game.dist_at(n)
			if nd >= 0 and nd < bd:
				bd = nd
				best = n
		if bd < 1000000 and (cd < 0 or bd < cd):
			prev_tile = cur_tile
			return best
	var cand: Array = []
	for n in opts:
		if n != prev_tile:
			cand.append(n)
	if cand.is_empty():
		cand = opts
	var pick: Vector2i = cand[randi() % cand.size()]
	prev_tile = cur_tile
	return pick


func _line_clear(pp: Vector3) -> bool:
	var a := Vector2(position.x, position.z)
	var b := Vector2(pp.x, pp.z)
	var dir: Vector2 = b - a
	var ln: float = dir.length()
	if ln < 0.01:
		return true
	dir /= ln
	var perp := Vector2(-dir.y, dir.x)
	var n: int = int(ln / 0.6)
	for off in [-0.35, 0.0, 0.35]:
		for i in range(1, n):
			var p: Vector2 = a + dir * (i * 0.6) + perp * off
			if maze.solid_world(p.x, p.y):
				return false
	return true


func _face(dv: Vector3, delta: float) -> void:
	var ang: float = atan2(dv.x, dv.z)
	visual.rotation.y = lerp_angle(visual.rotation.y, ang, 1.0 - exp(-10.0 * delta))


func _animate(delta: float) -> void:
	walk_t += delta * (7.0 if state == 1 else 4.0)
	for L in limbs:
		var mode: int = L.get_meta("mode")
		var ph: float = L.get_meta("phase")
		if mode == 0:
			L.rotation.x = sin(walk_t) * 0.7 * ph
		elif mode == 1:
			L.rotation.y = float(L.get_meta("base")) + sin(walk_t * 1.3 + ph) * 0.3
		elif mode == 2:
			L.rotation.y += delta * ph
		elif mode == 3:
			L.rotation.z = sin(walk_t * 0.5) * 0.25
	if bob:
		visual.position.y = 0.4 + sin(Time.get_ticks_msec() * 0.003 + walk_t * 0.1) * 0.15
	if anim_player != null:
		anim_player.speed_scale = 1.4 if state == 1 else 0.8
