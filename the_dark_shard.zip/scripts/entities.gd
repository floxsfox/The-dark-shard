extends RefCounted
# Helper mesh + 6 jenis monster prosedural (dipakai kalau model GLB tidak tersedia).
# Semua monster menghadap +Z.


static func mat(c: Color, em: float = 0.0, ec: Color = Color(0, 0, 0), rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	if em > 0.0:
		m.emission_enabled = true
		m.emission = ec
		m.emission_energy_multiplier = em
	return m


static func glow(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


static func add(parent: Node3D, mesh: Mesh, m: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi


static func cap(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = maxf(h, r * 2.0 + 0.01)
	c.radial_segments = 10
	c.rings = 4
	return c


static func sph(r: float, seg: int = 14) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = seg
	s.rings = maxi(seg / 2, 2)
	return s


static func octa() -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = 0.5
	s.height = 1.0
	s.radial_segments = 4
	s.rings = 2
	return s


static func cone(r: float, h: float, seg: int = 8) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = 0.0
	c.bottom_radius = r
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func cyl(r: float, h: float, seg: int = 10) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func box(x: float, y: float, z: float) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = Vector3(x, y, z)
	return b


static func pivot(parent: Node3D, pos: Vector3, mode: int, phase: float, base: float = 0.0) -> Node3D:
	var p := Node3D.new()
	p.position = pos
	p.rotation.y = base
	p.set_meta("mode", mode)
	p.set_meta("phase", phase)
	p.set_meta("base", base)
	parent.add_child(p)
	return p


# kind: 0 Penguntit, 1 Raksasa, 2 Laba-laba, 3 Hantu, 4 Boneka, 5 Kristal
static func build(kind: int, body_col: Color, eye_col: Color) -> Node3D:
	var root := Node3D.new()
	var limbs: Array = []
	var bob := false
	var body: StandardMaterial3D = mat(body_col, 0.0, Color(0, 0, 0), 0.7)
	var eye: StandardMaterial3D = mat(eye_col, 4.0, eye_col, 0.3)
	var bone: StandardMaterial3D = mat(Color(0.82, 0.8, 0.72), 0.0, Color(0, 0, 0), 0.6)
	match kind:
		0:
			add(root, cap(0.26, 1.6), body, Vector3(0, 1.5, 0))
			add(root, sph(0.23), body, Vector3(0, 2.5, 0.03), Vector3.ZERO, Vector3(1, 1.25, 1))
			for s in [-1.0, 1.0]:
				add(root, sph(0.05, 8), eye, Vector3(s * 0.09, 2.53, 0.2))
				add(root, cone(0.05, 0.7), body, Vector3(s * 0.14, 2.95, 0), Vector3(0, 0, -s * 0.5))
				add(root, cone(0.03, 0.35), body, Vector3(s * 0.34, 3.0, 0), Vector3(0, 0, -s * 1.0))
				var arm := pivot(root, Vector3(s * 0.34, 2.1, 0), 0, s)
				add(arm, cap(0.05, 1.5), body, Vector3(0, -0.75, 0))
				add(arm, cone(0.05, 0.3), bone, Vector3(0, -1.6, 0), Vector3(PI, 0, 0))
				var leg := pivot(root, Vector3(s * 0.12, 0.8, 0), 0, -s)
				add(leg, cap(0.06, 0.9), body, Vector3(0, -0.4, 0))
				limbs.append(arm)
				limbs.append(leg)
		1:
			add(root, sph(0.75), body, Vector3(0, 1.1, 0), Vector3.ZERO, Vector3(1.0, 1.1, 0.9))
			add(root, sph(0.33), body, Vector3(0, 2.0, 0.3))
			for s in [-1.0, 1.0]:
				add(root, sph(0.07, 8), eye, Vector3(s * 0.14, 2.05, 0.58))
				add(root, cone(0.1, 0.5), bone, Vector3(s * 0.22, 2.4, 0.3), Vector3(0.3, 0, -s * 0.5))
				var arm := pivot(root, Vector3(s * 0.85, 1.6, 0), 0, s)
				add(arm, cap(0.17, 1.3), body, Vector3(0, -0.6, 0))
				var leg := pivot(root, Vector3(s * 0.32, 0.55, 0), 0, -s)
				add(leg, cyl(0.2, 0.55), body, Vector3(0, -0.27, 0))
				limbs.append(arm)
				limbs.append(leg)
			for i in 4:
				add(root, cone(0.09, 0.45), bone, Vector3(0, 1.1 + i * 0.25, -0.66), Vector3(-1.2, 0, 0))
		2:
			add(root, sph(0.5), body, Vector3(0, 0.85, 0), Vector3.ZERO, Vector3(1.0, 0.7, 1.4))
			add(root, sph(0.27), body, Vector3(0, 0.95, 0.75))
			for s in [-1.0, 1.0]:
				add(root, sph(0.06, 8), eye, Vector3(s * 0.11, 1.05, 0.98))
				add(root, sph(0.04, 8), eye, Vector3(s * 0.2, 0.95, 0.95))
				for zi in 4:
					var zz: float = 0.5 - zi * 0.35
					var base: float = 0.0 if s > 0.0 else PI
					var lp := pivot(root, Vector3(s * 0.4, 0.85, zz), 1, zz * 7.0 + s, base)
					add(lp, cap(0.045, 1.2), body, Vector3(0.52, -0.3, 0), Vector3(0, 0, -2.1))
					limbs.append(lp)
		3:
			var cl := CylinderMesh.new()
			cl.top_radius = 0.28
			cl.bottom_radius = 0.85
			cl.height = 2.3
			cl.radial_segments = 14
			cl.rings = 1
			add(root, cl, body, Vector3(0, 1.4, 0))
			add(root, sph(0.3), body, Vector3(0, 2.7, 0.0), Vector3.ZERO, Vector3(1, 1.1, 1))
			add(root, sph(0.2), bone, Vector3(0, 2.68, 0.13))
			for s in [-1.0, 1.0]:
				add(root, sph(0.055, 8), eye, Vector3(s * 0.085, 2.7, 0.3))
				var arm := pivot(root, Vector3(s * 0.4, 2.2, 0.1), 0, s)
				add(arm, cap(0.05, 1.3), body, Vector3(0, -0.35, 0.45), Vector3(-1.2, 0, 0))
				limbs.append(arm)
			bob = true
		4:
			var skin: StandardMaterial3D = mat(Color(0.85, 0.82, 0.78), 0.0, Color(0, 0, 0), 0.4)
			var dark: StandardMaterial3D = mat(Color(0.02, 0.02, 0.02))
			add(root, cone(0.5, 1.2, 12), body, Vector3(0, 0.75, 0))
			var head := pivot(root, Vector3(0, 1.75, 0), 3, 0.0)
			add(head, sph(0.42), skin, Vector3.ZERO)
			for s in [-1.0, 1.0]:
				add(head, sph(0.1, 10), dark, Vector3(s * 0.17, 0.05, 0.34))
				add(head, sph(0.045, 8), eye, Vector3(s * 0.17, 0.05, 0.43))
				var arm := pivot(root, Vector3(s * 0.3, 1.25, 0), 0, s)
				add(arm, cap(0.04, 1.0), skin, Vector3(0, -0.5, 0))
				var leg := pivot(root, Vector3(s * 0.12, 0.35, 0), 0, -s)
				add(leg, cap(0.04, 0.7), skin, Vector3(0, -0.3, 0))
				limbs.append(arm)
				limbs.append(leg)
			add(head, box(0.32, 0.05, 0.05), dark, Vector3(0, -0.2, 0.4))
			limbs.append(head)
		5:
			var crys: StandardMaterial3D = mat(body_col.lerp(eye_col, 0.4), 2.0, eye_col, 0.2)
			add(root, octa(), crys, Vector3(0, 1.6, 0), Vector3.ZERO, Vector3(0.9, 1.8, 0.9))
			add(root, sph(0.2), eye, Vector3(0, 1.6, 0.4))
			for i in 4:
				var orb := pivot(root, Vector3(0, 1.6, 0), 2, 0.9 + i * 0.3)
				orb.rotation.y = i * 1.57
				add(orb, octa(), crys, Vector3(1.0, sin(i * 1.7) * 0.5, 0), Vector3(0, 0, 0.3), Vector3(0.3, 0.6, 0.3))
				limbs.append(orb)
			bob = true
	root.set_meta("limbs", limbs)
	root.set_meta("bob", bob)
	return root
