extends Control
# Layar tablet: peta garis putih di latar hitam, mengikuti arah pandang pemain.
# Titik hijau = shard, titik merah = monster (hanya saat Detector aktif), titik biru = pemain.

const S := 10   # piksel per tile di texture peta

var game
var map_tex: ImageTexture


func setup(g) -> void:
	game = g
	size = Vector2(320, 256)
	_build_tex()


func _opened(x: int, y: int) -> bool:
	var t: int = game.maze.get_t(x, y)
	return t == 0 or t == 3


func _build_tex() -> void:
	var m = game.maze
	var img := Image.create(m.W * S, m.H * S, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 1))
	var white := Color(1, 1, 1, 1)
	for y in range(m.H):
		for x in range(m.W):
			var t: int = m.get_t(x, y)
			if t == 0 or t == 3:
				continue
			if _opened(x - 1, y):
				img.fill_rect(Rect2i(x * S, y * S, 2, S), white)
			if _opened(x + 1, y):
				img.fill_rect(Rect2i((x + 1) * S - 2, y * S, 2, S), white)
			if _opened(x, y - 1):
				img.fill_rect(Rect2i(x * S, y * S, S, 2), white)
			if _opened(x, y + 1):
				img.fill_rect(Rect2i(x * S, (y + 1) * S - 2, S, 2), white)
	map_tex = ImageTexture.create_from_image(img)


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 1))
	if game == null or map_tex == null:
		return
	var tile: float = game.T
	var pp: Vector3 = game.player_pos
	var px := Vector2(pp.x / tile * S, pp.z / tile * S)
	var center := Vector2(size.x * 0.5, size.y * 0.62)
	var rot: float = -PI * 0.5 - atan2(-cos(game.yaw), -sin(game.yaw))
	var z := 0.95
	draw_set_transform(center, rot, Vector2(z, z))
	draw_texture(map_tex, -px)
	for i in game.shard_n:
		var sp: Vector3 = game.shard_pos[i]
		var q := Vector2(sp.x / tile * S, sp.z / tile * S) - px
		if q.length() < 200.0:
			draw_circle(q, 4.2, Color(0.15, 1.0, 0.3))
	if game.detector_on:
		for m in game.monsters:
			var q2 := Vector2(m.position.x / tile * S, m.position.z / tile * S) - px
			if q2.length() < 260.0:
				draw_circle(q2, 6.0, Color(1.0, 0.1, 0.1))
	draw_set_transform(center, 0.0, Vector2.ONE)
	draw_circle(Vector2.ZERO, 6.5, Color(0.2, 0.5, 1.0))
	draw_colored_polygon(PackedVector2Array([Vector2(0, -16), Vector2(7, -6), Vector2(-7, -6)]), Color(0.2, 0.5, 1.0))
