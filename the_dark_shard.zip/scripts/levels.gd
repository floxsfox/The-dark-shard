extends RefCounted
# Data level & skill. Ubah angka di sini untuk menyeimbangkan game.

const SKILLS = {
	"speed": {"name": "Speed", "label": "LARI", "cd": 12.0, "dur": 4.0, "price": 0, "need": "", "color": Color(1.0, 0.85, 0.2),
		"desc": "Lari 65% lebih cepat 4 detik. Bisa menabrak dan menghancurkan jaring merah. (Gratis)"},
	"flicker": {"name": "Flicker", "label": "KEDIP", "cd": 11.0, "dur": 3.0, "price": 90, "need": "", "color": Color(0.75, 0.5, 1.0),
		"desc": "Berkedip 9 meter ke depan lalu tak terlihat 3 detik. Monster kehilangan jejak."},
	"magnet": {"name": "Magnet", "label": "MAGNET", "cd": 18.0, "dur": 6.0, "price": 110, "need": "", "color": Color(0.3, 0.8, 1.0),
		"desc": "Menarik semua shard dalam radius 16 meter selama 6 detik."},
	"detector": {"name": "Detector", "label": "DETEKSI", "cd": 8.0, "dur": 20.0, "price": 130, "need": "red", "color": Color(1.0, 0.3, 0.3),
		"desc": "Butuh SHARD MERAH di level. Monster tampil di peta tablet dan tembus tembok selama 20 detik."},
	"stun": {"name": "Pelumpuh", "label": "LUMPUH", "cd": 6.0, "dur": 5.0, "price": 150, "need": "gold", "color": Color(1.0, 0.85, 0.2),
		"desc": "Butuh SHARD EMAS di level. Gelombang kejut melumpuhkan monster radius 11 meter selama 5 detik."},
}

const ORDER = ["speed", "flicker", "magnet", "detector", "stun"]

# Daftar skill yang dimiliki pemain, urut sesuai ORDER.
static func owned_list(owned: Array) -> Array:
	var res: Array = []
	for id in ORDER:
		if owned.has(id):
			res.append(id)
	return res

# Tambahan per level: jumlah jaring merah, shard merah/emas, langit.
const EXTRA = [
	{"nets": 2, "red": 2, "gold": 2, "open": true,
		"sky": {"top": Color(0.01, 0.02, 0.08), "hor": Color(0.05, 0.09, 0.13), "neb": Color(0.05, 0.12, 0.25), "moon_col": Color(0.85, 0.92, 1.0), "moon_dir": Vector3(0.4, 0.45, -0.75), "stars": 1.0, "moon_size": 0.9975}},
	{"nets": 3, "red": 2, "gold": 2, "open": false,
		"sky": {"top": Color(0.03, 0.01, 0.01), "hor": Color(0.08, 0.04, 0.03), "neb": Color(0.1, 0.03, 0.02), "moon_col": Color(1.0, 0.8, 0.6), "moon_dir": Vector3(0.3, 0.5, -0.8), "stars": 0.6, "moon_size": 0.998}},
	{"nets": 4, "red": 3, "gold": 3, "open": false,
		"sky": {"top": Color(0.01, 0.02, 0.05), "hor": Color(0.04, 0.06, 0.1), "neb": Color(0.05, 0.1, 0.2), "moon_col": Color(0.8, 0.9, 1.0), "moon_dir": Vector3(0.3, 0.5, -0.8), "stars": 1.0, "moon_size": 0.998}},
	{"nets": 5, "red": 3, "gold": 3, "open": true,
		"sky": {"top": Color(0.03, 0.035, 0.03), "hor": Color(0.2, 0.15, 0.06), "neb": Color(0.3, 0.16, 0.03), "moon_col": Color(1.0, 0.7, 0.4), "moon_dir": Vector3(-0.5, 0.35, -0.7), "stars": 0.35, "moon_size": 0.9985}},
	{"nets": 6, "red": 3, "gold": 3, "open": false,
		"sky": {"top": Color(0.05, 0.01, 0.1), "hor": Color(0.12, 0.04, 0.2), "neb": Color(0.3, 0.1, 0.5), "moon_col": Color(0.8, 0.6, 1.0), "moon_dir": Vector3(0.3, 0.5, -0.8), "stars": 0.8, "moon_size": 0.998}},
	{"nets": 7, "red": 4, "gold": 4, "open": true,
		"sky": {"top": Color(0.08, 0.0, 0.03), "hor": Color(0.35, 0.03, 0.05), "neb": Color(0.55, 0.0, 0.12), "moon_col": Color(1.0, 0.12, 0.08), "moon_dir": Vector3(0.2, 0.55, -0.8), "stars": 0.5, "moon_size": 0.985}},
]

const LEVELS = [
	{
		"name": "Taman Labirin",
		"sub": "Taman tua yang dijaga bayangan. Kumpulkan semua shard hijau sebelum mereka menemukanmu.",
		"ent_name": "Penjaga Taman & Rubah Bayangan",
		"seed": 7101, "cells": 15, "rooms": 5, "braid": 0.16, "shards": 90,
		"monsters": 2, "chase": 3.8, "patrol": 2.0, "sight": 16.0,
		"theme": "garden", "wh": 3.8, "open": true,
		"wall": "hedge", "floor": "grass", "ceil": "",
		"wall_tint": Color(0.75, 0.9, 0.75), "floor_tint": Color(0.65, 0.75, 0.65), "ceil_tint": Color(1, 1, 1),
		"wall_a": Color(0.03, 0.14, 0.04), "wall_b": Color(0.12, 0.38, 0.10),
		"floor_a": Color(0.05, 0.12, 0.04), "floor_b": Color(0.15, 0.25, 0.08),
		"fog": Color(0.02, 0.05, 0.07), "fog_d": 0.032, "ambient": Color(0.18, 0.24, 0.35), "amb_e": 0.6,
		"lamp": Color(1.0, 0.78, 0.45), "eye": Color(1.0, 0.85, 0.1), "body": Color(0.03, 0.04, 0.03),
		"ents": [{"m": 1, "k": 0}, {"m": 0, "k": 0}],
	},
	{
		"name": "Mansion Terlupakan",
		"sub": "Lorong gelap, ruang makan, dan perpustakaan. Sesuatu berjalan di balik dinding.",
		"ent_name": "Pria Bayangan & Boneka Retak",
		"seed": 7202, "cells": 17, "rooms": 7, "braid": 0.18, "shards": 110,
		"monsters": 3, "chase": 4.0, "patrol": 2.1, "sight": 17.0,
		"theme": "mansion", "wh": 3.4, "open": false,
		"wall": "plaster", "floor": "wood", "ceil": "wood",
		"wall_tint": Color(0.75, 0.62, 0.55), "floor_tint": Color(0.7, 0.6, 0.55), "ceil_tint": Color(0.5, 0.42, 0.4),
		"wall_a": Color(0.18, 0.1, 0.08), "wall_b": Color(0.32, 0.2, 0.14),
		"floor_a": Color(0.12, 0.07, 0.04), "floor_b": Color(0.28, 0.16, 0.08),
		"fog": Color(0.05, 0.03, 0.03), "fog_d": 0.045, "ambient": Color(0.3, 0.2, 0.16), "amb_e": 0.6,
		"lamp": Color(1.0, 0.6, 0.3), "eye": Color(1.0, 0.1, 0.1), "body": Color(0.07, 0.05, 0.05),
		"ents": [{"m": 2, "k": 0}, {"m": 0, "k": 4}, {"m": 0, "k": 4}],
	},
	{
		"name": "Katakombe Tulang",
		"sub": "Terowongan batu penuh peti mati. Hantu berjubah melayang tanpa suara.",
		"ent_name": "Hantu Berjubah & Raksasa Tulang",
		"seed": 7303, "cells": 19, "rooms": 8, "braid": 0.2, "shards": 130,
		"monsters": 4, "chase": 4.2, "patrol": 2.2, "sight": 18.0,
		"theme": "crypt", "wh": 3.6, "open": false,
		"wall": "bricks", "floor": "pavers", "ceil": "bricks",
		"wall_tint": Color(0.7, 0.7, 0.75), "floor_tint": Color(0.6, 0.6, 0.65), "ceil_tint": Color(0.45, 0.45, 0.5),
		"wall_a": Color(0.1, 0.1, 0.12), "wall_b": Color(0.28, 0.27, 0.3),
		"floor_a": Color(0.08, 0.08, 0.1), "floor_b": Color(0.2, 0.2, 0.24),
		"fog": Color(0.02, 0.04, 0.06), "fog_d": 0.05, "ambient": Color(0.18, 0.22, 0.32), "amb_e": 0.6,
		"lamp": Color(1.0, 0.55, 0.2), "eye": Color(0.5, 0.85, 1.0), "body": Color(0.05, 0.05, 0.07),
		"ents": [{"m": 0, "k": 3}, {"m": 0, "k": 1}, {"m": 0, "k": 3}, {"m": 0, "k": 1}],
	},
	{
		"name": "Pabrik Berkarat",
		"sub": "Mesin mati, pipa bocor, dan banyak kaki laba-laba logam di kegelapan.",
		"ent_name": "Laba-laba Karat & Raksasa Besi",
		"seed": 7404, "cells": 21, "rooms": 10, "braid": 0.2, "shards": 150,
		"monsters": 5, "chase": 4.4, "patrol": 2.3, "sight": 19.0,
		"theme": "factory", "wh": 3.8, "open": false,
		"wall": "metal", "floor": "metalfloor", "ceil": "concrete",
		"wall_tint": Color(0.75, 0.6, 0.5), "floor_tint": Color(0.6, 0.6, 0.6), "ceil_tint": Color(0.45, 0.45, 0.45),
		"wall_a": Color(0.2, 0.1, 0.06), "wall_b": Color(0.4, 0.22, 0.12),
		"floor_a": Color(0.1, 0.1, 0.1), "floor_b": Color(0.22, 0.22, 0.22),
		"fog": Color(0.03, 0.05, 0.04), "fog_d": 0.05, "ambient": Color(0.18, 0.26, 0.22), "amb_e": 0.6,
		"lamp": Color(0.9, 0.95, 0.55), "eye": Color(1.0, 0.4, 0.05), "body": Color(0.12, 0.07, 0.04),
		"ents": [{"m": 0, "k": 2}, {"m": 0, "k": 1}, {"m": 0, "k": 2}, {"m": 0, "k": 2}, {"m": 0, "k": 1}],
	},
	{
		"name": "Gua Kristal Ungu",
		"sub": "Gua raksasa berpendar ungu. Kristal hidup mengawasi setiap langkahmu.",
		"ent_name": "Penjaga Kristal, Boneka & Laba-laba",
		"seed": 7505, "cells": 23, "rooms": 12, "braid": 0.22, "shards": 175,
		"monsters": 6, "chase": 4.6, "patrol": 2.4, "sight": 20.0,
		"theme": "cave", "wh": 4.2, "open": false,
		"wall": "rock", "floor": "ground", "ceil": "rock",
		"wall_tint": Color(0.65, 0.55, 0.8), "floor_tint": Color(0.55, 0.5, 0.65), "ceil_tint": Color(0.4, 0.35, 0.5),
		"wall_a": Color(0.1, 0.06, 0.16), "wall_b": Color(0.26, 0.16, 0.38),
		"floor_a": Color(0.08, 0.05, 0.12), "floor_b": Color(0.18, 0.12, 0.26),
		"fog": Color(0.05, 0.02, 0.09), "fog_d": 0.045, "ambient": Color(0.3, 0.16, 0.45), "amb_e": 0.65,
		"lamp": Color(0.7, 0.35, 1.0), "eye": Color(1.0, 0.2, 0.9), "body": Color(0.07, 0.04, 0.1),
		"ents": [{"m": 0, "k": 2}, {"m": 0, "k": 5}, {"m": 0, "k": 4}, {"m": 0, "k": 2}, {"m": 0, "k": 5}, {"m": 0, "k": 4}],
	},
	{
		"name": "Inti Kegelapan",
		"sub": "Level terakhir. Semua makhluk berkumpul di sini, dan semua skillmu menjadi lebih kuat.",
		"ent_name": "Seluruh Makhluk Kegelapan",
		"seed": 7606, "cells": 25, "rooms": 14, "braid": 0.24, "shards": 200,
		"monsters": 7, "chase": 4.8, "patrol": 2.5, "sight": 22.0,
		"theme": "void", "wh": 4.2, "open": false,
		"wall": "obsidian", "floor": "marble", "ceil": "obsidian",
		"wall_tint": Color(0.6, 0.5, 0.55), "floor_tint": Color(0.5, 0.45, 0.5), "ceil_tint": Color(0.35, 0.3, 0.33),
		"wall_a": Color(0.03, 0.01, 0.03), "wall_b": Color(0.14, 0.04, 0.07),
		"floor_a": Color(0.03, 0.02, 0.03), "floor_b": Color(0.12, 0.05, 0.07),
		"fog": Color(0.08, 0.0, 0.02), "fog_d": 0.055, "ambient": Color(0.4, 0.08, 0.1), "amb_e": 0.65,
		"lamp": Color(1.0, 0.15, 0.1), "eye": Color(1.0, 0.05, 0.05), "body": Color(0.02, 0.0, 0.02),
		"ents": [{"m": 0, "k": 5}, {"m": 0, "k": 3}, {"m": 0, "k": 0}, {"m": 0, "k": 1}, {"m": 0, "k": 2}, {"m": 0, "k": 4}, {"m": 0, "k": 5}],
	},
]
