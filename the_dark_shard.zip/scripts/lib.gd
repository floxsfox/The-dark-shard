extends RefCounted
# Pemuat texture (hasil unduhan CI), material, dan sintesis suara.

static var cache := {}


static func clear_cache() -> void:
	cache.clear()


# Texture disimpan sebagai assets/textures/<nama>_<color|normal|rough>.dat (JPEG).
static func load_tex(tname: String, kind: String) -> Texture2D:
	if tname == "":
		return null
	var key: String = tname + "_" + kind
	if cache.has(key):
		return cache[key]
	var path := "res://assets/textures/%s_%s.dat" % [tname, kind]
	var tex: Texture2D = null
	if FileAccess.file_exists(path):
		var bytes: PackedByteArray = FileAccess.get_file_as_bytes(path)
		var img := Image.new()
		if bytes.size() > 100 and img.load_jpg_from_buffer(bytes) == OK:
			img.generate_mipmaps()
			tex = ImageTexture.create_from_image(img)
	cache[key] = tex
	return tex


static func proc_tex(a: Color, b: Color, seed_val: int, size: int = 128) -> Texture2D:
	var n := FastNoiseLite.new()
	n.seed = seed_val
	n.frequency = 0.045
	n.fractal_octaves = 4
	var g: Image = n.get_seamless_image(size, size)
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var v: float = g.get_pixel(x, y).r
			img.set_pixel(x, y, a.lerp(b, v))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func make_mat(tname: String, tint: Color, uv: float, tri: bool, fa: Color, fb: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	var c: Texture2D = load_tex(tname, "color")
	if c != null:
		m.albedo_texture = c
		m.albedo_color = tint
		var n: Texture2D = load_tex(tname, "normal")
		if n != null:
			m.normal_enabled = true
			m.normal_texture = n
			m.normal_scale = 1.2
		var r: Texture2D = load_tex(tname, "rough")
		if r != null:
			m.roughness_texture = r
			m.roughness = 1.0
		else:
			m.roughness = rough
	else:
		m.albedo_texture = proc_tex(fa, fb, hash(tname + "x"))
		m.roughness = rough
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if tri:
		m.uv1_triplanar = true
		m.uv1_world_triplanar = true
		m.uv1_scale = Vector3(uv, uv, uv)
	else:
		m.uv1_scale = Vector3(uv, uv, 1.0)
	return m


# Sintesis suara sederhana (16-bit mono)
static func synth(f0: float, f1: float, dur: float, vol: float, noise: float = 0.0, decay: float = 3.0) -> AudioStreamWAV:
	var rate := 22050
	var n: int = int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	var rng := RandomNumberGenerator.new()
	rng.seed = 12345
	for i in n:
		var t: float = float(i) / float(n)
		var f: float = lerpf(f0, f1, t)
		ph += TAU * f / float(rate)
		var env: float = pow(1.0 - t, decay) * minf(1.0, t * 80.0)
		var s: float = sin(ph) * (1.0 - noise) + (rng.randf() * 2.0 - 1.0) * noise
		data.encode_s16(i * 2, int(clampf(s * env * vol, -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	return w


# Drone ambient yang bisa di-loop mulus (4 detik)
static func drone() -> AudioStreamWAV:
	var rate := 22050
	var n: int = rate * 4
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t: float = float(i) / float(rate)
		var s: float = sin(TAU * 55.0 * t) * 0.5 + sin(TAU * 82.5 * t) * 0.3 + sin(TAU * 110.25 * t) * 0.1
		s *= 0.6 + 0.4 * sin(TAU * 0.5 * t)
		data.encode_s16(i * 2, int(s * 9000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = n
	return w


const SKY_SHADER := """
shader_type sky;
uniform vec3 top_col : source_color = vec3(0.01, 0.02, 0.08);
uniform vec3 hor_col : source_color = vec3(0.05, 0.08, 0.12);
uniform vec3 neb_col : source_color = vec3(0.1, 0.1, 0.3);
uniform vec3 moon_col : source_color = vec3(0.85, 0.9, 1.0);
uniform vec3 moon_dir = vec3(0.4, 0.5, -0.7);
uniform float star_amt = 1.0;
uniform float moon_size = 0.9975;

float hash31(vec3 p) {
	p = fract(p * 0.3183099 + vec3(0.1, 0.1, 0.1));
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float vnoise(vec3 p) {
	vec3 i = floor(p);
	vec3 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = mix(hash31(i), hash31(i + vec3(1.0, 0.0, 0.0)), f.x);
	float b = mix(hash31(i + vec3(0.0, 1.0, 0.0)), hash31(i + vec3(1.0, 1.0, 0.0)), f.x);
	float c = mix(hash31(i + vec3(0.0, 0.0, 1.0)), hash31(i + vec3(1.0, 0.0, 1.0)), f.x);
	float d = mix(hash31(i + vec3(0.0, 1.0, 1.0)), hash31(i + vec3(1.0, 1.0, 1.0)), f.x);
	return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
}

void sky() {
	vec3 d = normalize(EYEDIR);
	float h = clamp(d.y, 0.0, 1.0);
	vec3 col = mix(hor_col, top_col, pow(h, 0.45));
	if (d.y < 0.0) {
		col = hor_col * 0.5;
	}
	float n = vnoise(d * 3.0) * 0.6 + vnoise(d * 7.0) * 0.3 + vnoise(d * 15.0) * 0.1;
	col += neb_col * smoothstep(0.45, 0.9, n) * smoothstep(0.0, 0.5, d.y);
	vec3 sp = d * 180.0;
	vec3 cell = floor(sp);
	float rnd = hash31(cell);
	vec3 off = fract(sp) - vec3(0.5, 0.5, 0.5);
	float star = step(0.992, rnd) * (1.0 - smoothstep(0.0, 0.35, length(off))) * (0.4 + 0.6 * hash31(cell + vec3(7.0, 7.0, 7.0)));
	col += vec3(star) * star_amt * smoothstep(0.0, 0.25, d.y);
	vec3 md = normalize(moon_dir);
	float dm = dot(d, md);
	col += moon_col * smoothstep(moon_size, moon_size + 0.0006, dm);
	col += moon_col * 0.12 * pow(max(dm, 0.0), 40.0);
	COLOR = col;
}
"""


# Skybox malam berbintang + bulan + nebula (shader sky, tanpa file gambar)
static func make_sky(sd: Dictionary) -> Sky:
	var sh := Shader.new()
	sh.code = SKY_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("top_col", sd.top)
	m.set_shader_parameter("hor_col", sd.hor)
	m.set_shader_parameter("neb_col", sd.neb)
	m.set_shader_parameter("moon_col", sd.moon_col)
	m.set_shader_parameter("moon_dir", sd.moon_dir)
	m.set_shader_parameter("star_amt", float(sd.stars))
	m.set_shader_parameter("moon_size", float(sd.moon_size))
	var sky := Sky.new()
	sky.sky_material = m
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	return sky


# Texture jaring merah: garis diagonal merah di atas latar transparan
static func net_texture() -> Texture2D:
	var n := 64
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var red := Color(1.0, 0.06, 0.06, 1.0)
	for y in n:
		for x in n:
			if (x + y) % 32 < 4 or (x - y + n) % 32 < 4:
				img.set_pixel(x, y, red)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)
