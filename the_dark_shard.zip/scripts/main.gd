extends Node
# Alur: menu -> lobi (6 portal + patung toko skill) -> briefing -> level -> hasil -> lobi.

const GameScript = preload("res://scripts/game.gd")
const HubScript = preload("res://scripts/hub.gd")
const Levels = preload("res://scripts/levels.gd")
const SAVE_PATH := "user://darkshard.cfg"

var cfg := {"unlocked": 1, "sens": 1.0, "shadows": true, "wallet": 0, "owned": ["speed"], "track": 0}
var plan: Array = [0, 1, 2, 0, 1, 2]   # soundtrack tiap level (diacak tiap kali game dibuka)
var game = null
var hub = null
var cur_level := 0
var ui: CanvasLayer
var ui_root: Control
var screens := {}
var pause_layer: CanvasLayer
var brief_title: Label
var brief_text: Label
var brief_skill: Label
var res_title: Label
var res_text: Label
var res_next: Button
var shop_wallet: Label
var shop_list: VBoxContainer
var pause_retry: Button
var pause_lobby: Button
var th: Theme


func _ready() -> void:
	plan.shuffle()
	_load_cfg()
	th = _make_theme()
	ui = CanvasLayer.new()
	ui.layer = 10
	ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui)
	ui_root = Control.new()
	ui_root.theme = th
	ui.add_child(ui_root)
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_menu()
	_build_settings()
	_build_credits()
	_build_brief()
	_build_result()
	_build_shop()
	_build_pause()
	_show("menu")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if game != null or hub != null:
			if screens["brief"].visible:
				_brief_back()
			elif screens["shop"].visible:
				_close_shop()
			elif not ui.visible:
				_on_pause()
		elif not screens["menu"].visible:
			_show("menu")


# ------------------------------------------------------------ simpan/muat
func _load_cfg() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		cfg["unlocked"] = int(cf.get_value("save", "unlocked", 1))
		cfg["wallet"] = int(cf.get_value("save", "wallet", 0))
		var ow = cf.get_value("save", "owned", ["speed"])
		var arr: Array = []
		for x in ow:
			arr.append(String(x))
		if not arr.has("speed"):
			arr.append("speed")
		cfg["owned"] = arr
		cfg["sens"] = float(cf.get_value("settings", "sens", 1.0))
		cfg["shadows"] = bool(cf.get_value("settings", "shadows", true))


func _save_cfg() -> void:
	var cf := ConfigFile.new()
	cf.set_value("save", "unlocked", cfg["unlocked"])
	cf.set_value("save", "wallet", cfg["wallet"])
	cf.set_value("save", "owned", cfg["owned"])
	cf.set_value("settings", "sens", cfg["sens"])
	cf.set_value("settings", "shadows", cfg["shadows"])
	cf.save(SAVE_PATH)


# ------------------------------------------------------------ helper UI
func _make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 26
	t.set_stylebox("normal", "Button", _sb(Color(0.04, 0.12, 0.08, 0.92), Color(0.25, 0.85, 0.45)))
	t.set_stylebox("hover", "Button", _sb(Color(0.06, 0.2, 0.12, 0.95), Color(0.5, 1.0, 0.65)))
	t.set_stylebox("pressed", "Button", _sb(Color(0.1, 0.32, 0.18, 1.0), Color(0.7, 1.0, 0.8)))
	t.set_stylebox("disabled", "Button", _sb(Color(0.05, 0.06, 0.06, 0.9), Color(0.2, 0.25, 0.22)))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color(0.85, 1.0, 0.9))
	t.set_color("font_disabled_color", "Button", Color(0.4, 0.45, 0.42))
	return t


func _sb(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(12)
	s.set_content_margin_all(12)
	return s


func _label(parent: Control, text: String, size: int = 26, col: Color = Color(0.85, 0.95, 0.9)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l


func _button(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _screen(nm: String, title: String, width: float = 700.0) -> VBoxContainer:
	var scr := Control.new()
	ui_root.add_child(scr)
	scr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.015, 0.025, 0.03)
	scr.add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	scr.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(width, 0)
	cc.add_child(vb)
	_label(vb, title, 52, Color(0.4, 1.0, 0.55))
	screens[nm] = scr
	return vb


func _show(nm: String) -> void:
	for k in screens:
		screens[k].visible = (k == nm)
	ui.visible = (nm != "")


# ------------------------------------------------------------ layar
func _build_menu() -> void:
	var vb := _screen("menu", "THE DARK SHARD")
	_label(vb, "Kumpulkan semua shard. Jangan sampai tertangkap.", 24, Color(0.6, 0.75, 0.7))
	_button(vb, "MAIN", func(): start_hub())
	_button(vb, "PENGATURAN", func(): _show("settings"))
	_button(vb, "KREDIT", func(): _show("credits"))


func _build_settings() -> void:
	var vb := _screen("settings", "PENGATURAN")
	_label(vb, "Sensitivitas kamera", 24)
	var sl := HSlider.new()
	sl.min_value = 0.4
	sl.max_value = 2.5
	sl.step = 0.1
	sl.value = float(cfg["sens"])
	sl.custom_minimum_size = Vector2(0, 50)
	sl.value_changed.connect(func(v): cfg["sens"] = v; _save_cfg())
	vb.add_child(sl)
	var cb := CheckButton.new()
	cb.text = "Bayangan senter (lebih bagus, lebih berat)"
	cb.button_pressed = bool(cfg["shadows"])
	cb.toggled.connect(func(on): cfg["shadows"] = on; _save_cfg())
	vb.add_child(cb)
	_button(vb, "RESET PROGRESS", func(): _reset_progress())
	_button(vb, "KEMBALI", func(): _show("menu"))


func _reset_progress() -> void:
	cfg["unlocked"] = 1
	cfg["wallet"] = 0
	cfg["owned"] = ["speed"]
	_save_cfg()


func _build_credits() -> void:
	var vb := _screen("credits", "KREDIT", 900.0)
	_label(vb, "Game: The Dark Shard (Godot 4)\nSFX shard & soundtrack: file dari pembuat game.\nTexture: ambientCG (CC0) - ambientcg.com\nModel Rubah: PixelMannen (CC0), rigging & animasi tomkranis (CC-BY 4.0).\nModel Pria Bayangan: CesiumMan oleh Cesium (CC-BY 4.0).\nModel dari glTF Sample Assets (Khronos Group).\nMonster lain, lobi, dan peta dibuat lewat kode.", 22)
	_button(vb, "KEMBALI", func(): _show("menu"))


func _build_brief() -> void:
	var vb := _screen("brief", "LEVEL", 860.0)
	brief_title = vb.get_child(0)
	brief_text = _label(vb, "", 24, Color(0.75, 0.85, 0.8))
	brief_skill = _label(vb, "", 22, Color(1.0, 0.9, 0.4))
	_label(vb, "Kiri layar: joystick  |  Kanan layar: geser untuk melihat  |  Tablet di tangan kiri = peta", 20, Color(0.6, 0.7, 0.66))
	_button(vb, "MULAI", func(): start_level(cur_level))
	_button(vb, "KEMBALI", func(): _brief_back())


func _open_brief(i: int) -> void:
	cur_level = i
	var L: Dictionary = Levels.LEVELS[i]
	var X: Dictionary = Levels.EXTRA[i]
	brief_title.text = "LEVEL %d  -  %s" % [i + 1, String(L.name).to_upper()]
	brief_text.text = "%s\nMonster: %s\nShard: %d   |   Jaring merah: %d" % [L.sub, L.ent_name, L.shards, X.nets]
	var owned: Array = cfg["owned"]
	var names: Array = []
	for id in Levels.ORDER:
		if owned.has(id):
			names.append(String(Levels.SKILLS[id].name))
	var tip := "Skill aktif: " + ", ".join(PackedStringArray(names))
	if owned.has("detector"):
		tip += "\nCari SHARD MERAH (%d di level ini) untuk mengaktifkan Detector." % int(X.red)
	if owned.has("stun"):
		tip += "\nCari SHARD EMAS (%d di level ini) untuk memakai Pelumpuh." % int(X.gold)
	tip += "\nJaring merah hanya hancur kalau ditabrak saat Speed aktif."
	if i == 5:
		tip += "\nUPGRADE level ini: semua skill lebih lama aktif, cooldown -40%."
	brief_skill.text = tip
	_show("brief")


func _brief_back() -> void:
	if hub != null:
		get_tree().paused = false
		_show("")
		hub.reset_player()
	else:
		start_hub()


func _build_result() -> void:
	var vb := _screen("result", "HASIL", 760.0)
	res_title = vb.get_child(0)
	res_text = _label(vb, "", 26)
	res_next = _button(vb, "LEVEL BERIKUTNYA", func(): _open_brief(mini(cur_level + 1, 5)))
	_button(vb, "ULANGI LEVEL", func(): start_level(cur_level))
	_button(vb, "KE LOBI (BELI SKILL)", func(): start_hub())


func _build_shop() -> void:
	var vb := _screen("shop", "PATUNG SKILL", 960.0)
	shop_wallet = _label(vb, "", 28, Color(0.5, 1.0, 0.65))
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(960, 380)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	shop_list = VBoxContainer.new()
	shop_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_list.add_theme_constant_override("separation", 10)
	sc.add_child(shop_list)
	_button(vb, "TUTUP", func(): _close_shop())


func _refresh_shop() -> void:
	shop_wallet.text = "Shard kamu: %d" % int(cfg["wallet"])
	for c in shop_list.get_children():
		c.queue_free()
	var owned: Array = cfg["owned"]
	for id in Levels.ORDER:
		var S: Dictionary = Levels.SKILLS[id]
		var have: bool = owned.has(id)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var l := Label.new()
		var price_txt: String = "DIMILIKI" if have else "%d shard" % int(S.price)
		l.text = "%s  -  %s\n%s" % [String(S.name).to_upper(), price_txt, S.desc]
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.add_theme_font_size_override("font_size", 20)
		row.add_child(l)
		var b := Button.new()
		b.text = "DIMILIKI" if have else "BELI"
		b.custom_minimum_size = Vector2(190, 84)
		b.disabled = have or int(cfg["wallet"]) < int(S.price)
		b.pressed.connect(func(): _buy(id))
		row.add_child(b)
		shop_list.add_child(row)


func _buy(id: String) -> void:
	var price: int = int(Levels.SKILLS[id].price)
	if int(cfg["wallet"]) >= price and not (cfg["owned"] as Array).has(id):
		cfg["wallet"] = int(cfg["wallet"]) - price
		(cfg["owned"] as Array).append(id)
		_save_cfg()
		_refresh_shop()


func _open_shop() -> void:
	get_tree().paused = true
	_refresh_shop()
	_show("shop")


func _close_shop() -> void:
	get_tree().paused = false
	_show("")
	if hub != null:
		hub.hud.reset_touch()


func _build_pause() -> void:
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 20
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_layer.visible = false
	add_child(pause_layer)
	var root := Control.new()
	root.theme = th
	pause_layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	root.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(560, 0)
	cc.add_child(vb)
	_label(vb, "JEDA", 52, Color(0.4, 1.0, 0.55))
	_button(vb, "LANJUTKAN", func(): _on_resume())
	pause_retry = _button(vb, "ULANGI LEVEL", func(): _on_resume(); start_level(cur_level))
	pause_lobby = _button(vb, "KE LOBI", func(): _on_resume(); start_hub())
	_button(vb, "MENU UTAMA", func(): _on_resume(); _end_game(); _end_hub(); _show("menu"))


# ------------------------------------------------------------ alur
func _end_game() -> void:
	if game != null:
		game.queue_free()
		game = null


func _end_hub() -> void:
	if hub != null:
		hub.queue_free()
		hub = null


func start_hub() -> void:
	_end_game()
	_end_hub()
	get_tree().paused = false
	pause_layer.visible = false
	hub = HubScript.new()
	hub.setup(cfg)
	add_child(hub)
	hub.portal_entered.connect(_on_portal)
	hub.shop_requested.connect(_open_shop)
	hub.pause_requested.connect(_on_pause)
	_show("")


func _on_portal(i: int) -> void:
	get_tree().paused = true
	_open_brief(i)


func start_level(i: int) -> void:
	cur_level = i
	_end_game()
	_end_hub()
	get_tree().paused = false
	pause_layer.visible = false
	cfg["track"] = int(plan[i])
	game = GameScript.new()
	game.setup(i, cfg)
	add_child(game)
	game.level_done.connect(_on_done)
	game.pause_requested.connect(_on_pause)
	_show("")


func _on_pause() -> void:
	if (game == null and hub == null) or get_tree().paused:
		return
	pause_retry.visible = game != null
	pause_lobby.visible = game != null
	get_tree().paused = true
	pause_layer.visible = true


func _on_resume() -> void:
	get_tree().paused = false
	pause_layer.visible = false
	if game != null:
		game.hud.reset_touch()
	if hub != null:
		hub.hud.reset_touch()


func _on_done(won: bool) -> void:
	var t: float = game.elapsed
	var lives_left: int = game.lives
	var got: int = game.collected()
	_end_game()
	var gain: int = got if won else got / 2
	cfg["wallet"] = int(cfg["wallet"]) + gain
	if won:
		if cur_level < 5 and int(cfg["unlocked"]) < cur_level + 2:
			cfg["unlocked"] = cur_level + 2
		var last := cur_level >= 5
		res_title.text = "TAMAT!" if last else "LEVEL SELESAI"
		res_text.text = "Waktu: %d:%02d   |   Nyawa tersisa: %d\nShard didapat: +%d (total %d)" % [int(t) / 60, int(t) % 60, lives_left, gain, int(cfg["wallet"])]
		if last:
			res_text.text += "\nKamu mengalahkan kegelapan dan mengumpulkan semua shard."
		res_next.visible = not last
	else:
		res_title.text = "GAME OVER"
		res_text.text = "Monster menangkapmu. Coba lagi!\nShard didapat: +%d (total %d)" % [gain, int(cfg["wallet"])]
		res_next.visible = false
	_save_cfg()
	_show("result")
