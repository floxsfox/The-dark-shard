extends Node
# Alur aplikasi: menu -> pilih level -> briefing -> game -> hasil. Semua UI dibuat lewat kode.

const GameScript = preload("res://scripts/game.gd")
const Levels = preload("res://scripts/levels.gd")
const SAVE_PATH := "user://darkshard.cfg"

var cfg := {"unlocked": 1, "sens": 1.0, "shadows": true}
var game = null
var cur_level := 0
var ui: CanvasLayer
var ui_root: Control
var screens := {}
var pause_layer: CanvasLayer
var select_grid: GridContainer
var brief_title: Label
var brief_text: Label
var brief_skill: Label
var res_title: Label
var res_text: Label
var res_next: Button
var th: Theme


func _ready() -> void:
	_load_cfg()
	th = _make_theme()
	ui = CanvasLayer.new()
	ui.layer = 10
	add_child(ui)
	ui_root = Control.new()
	ui_root.theme = th
	ui.add_child(ui_root)
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_menu()
	_build_select()
	_build_settings()
	_build_credits()
	_build_brief()
	_build_result()
	_build_pause()
	_show("menu")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if game != null:
			_on_pause()
		elif not screens["menu"].visible:
			_show("menu")


# ------------------------------------------------------------ simpan/muat
func _load_cfg() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		cfg["unlocked"] = int(cf.get_value("save", "unlocked", 1))
		cfg["sens"] = float(cf.get_value("settings", "sens", 1.0))
		cfg["shadows"] = bool(cf.get_value("settings", "shadows", true))


func _save_cfg() -> void:
	var cf := ConfigFile.new()
	cf.set_value("save", "unlocked", cfg["unlocked"])
	cf.set_value("settings", "sens", cfg["sens"])
	cf.set_value("settings", "shadows", cfg["shadows"])
	cf.save(SAVE_PATH)


# ------------------------------------------------------------ helper UI
func _make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 26
	t.set_stylebox("normal", "Button", _sb(Color(0.04, 0.12, 0.08, 0.92), Color(0.25, 0.85, 0.45)))
	t.set_stylebox("hover", "Button", _sb(Color(0.06, 0.2, 0.12, 0.95), Color(0.5, 1.0, 0.65)))
	t.set_stylebox("pressed", "Button", _sb(Color(0.1, 0.32, 0.18, 1.0), Color(0.7, 1.0, 0.8)))
	t.set_stylebox("disabled", "Button", _sb(Color(0.05, 0.06, 0.06, 0.9), Color(0.2, 0.25, 0.22)))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color(0.85, 1.0, 0.9))
	t.set_color("font_disabled_color", "Button", Color(0.4, 0.45, 0.42))
	return t


func _sb(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(12)
	s.set_content_margin_all(12)
	return s


func _label(parent: Control, text: String, size: int = 26, col: Color = Color(0.85, 0.95, 0.9)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l


func _button(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _screen(nm: String, title: String, width: float = 700.0) -> VBoxContainer:
	var scr := Control.new()
	ui_root.add_child(scr)
	scr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.015, 0.025, 0.03)
	scr.add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	scr.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(width, 0)
	cc.add_child(vb)
	_label(vb, title, 52, Color(0.4, 1.0, 0.55))
	screens[nm] = scr
	return vb


func _show(nm: String) -> void:
	for k in screens:
		screens[k].visible = (k == nm)
	ui.visible = (nm != "")


# ------------------------------------------------------------ layar
func _build_menu() -> void:
	var vb := _screen("menu", "THE DARK SHARD")
	_label(vb, "Kumpulkan semua shard. Jangan sampai tertangkap.", 24, Color(0.6, 0.75, 0.7))
	_button(vb, "MAIN", func(): _open_brief(clampi(int(cfg["unlocked"]) - 1, 0, 5)))
	_button(vb, "PILIH LEVEL", func(): _refresh_select(); _show("select"))
	_button(vb, "PENGATURAN", func(): _show("settings"))
	_button(vb, "KREDIT", func(): _show("credits"))


func _build_select() -> void:
	var vb := _screen("select", "PILIH LEVEL", 900.0)
	select_grid = GridContainer.new()
	select_grid.columns = 2
	select_grid.add_theme_constant_override("h_separation", 12)
	select_grid.add_theme_constant_override("v_separation", 12)
	vb.add_child(select_grid)
	_button(vb, "KEMBALI", func(): _show("menu"))


func _refresh_select() -> void:
	for c in select_grid.get_children():
		c.queue_free()
	for i in 6:
		var L: Dictionary = Levels.LEVELS[i]
		var sk := "Semua skill diperkuat" if i == 5 else "Skill baru: " + String(Levels.SKILLS[Levels.ORDER[i]].name)
		var b := Button.new()
		b.text = "%d. %s\n%s" % [i + 1, L.name, sk]
		b.custom_minimum_size = Vector2(440, 104)
		b.disabled = i >= int(cfg["unlocked"])
		b.pressed.connect(func(): _open_brief(i))
		select_grid.add_child(b)


func _build_settings() -> void:
	var vb := _screen("settings", "PENGATURAN")
	_label(vb, "Sensitivitas kamera", 24)
	var sl := HSlider.new()
	sl.min_value = 0.4
	sl.max_value = 2.5
	sl.step = 0.1
	sl.value = float(cfg["sens"])
	sl.custom_minimum_size = Vector2(0, 50)
	sl.value_changed.connect(func(v): cfg["sens"] = v; _save_cfg())
	vb.add_child(sl)
	var cb := CheckButton.new()
	cb.text = "Bayangan senter (lebih bagus, lebih berat)"
	cb.button_pressed = bool(cfg["shadows"])
	cb.toggled.connect(func(on): cfg["shadows"] = on; _save_cfg())
	vb.add_child(cb)
	_button(vb, "RESET PROGRESS", func(): cfg["unlocked"] = 1; _save_cfg())
	_button(vb, "KEMBALI", func(): _show("menu"))


func _build_credits() -> void:
	var vb := _screen("credits", "KREDIT", 900.0)
	_label(vb, "Game: The Dark Shard (Godot 4)\nSFX shard: file dari pembuat game.\nTexture: ambientCG (CC0) - ambientcg.com\nModel Rubah: PixelMannen (CC0), rigging & animasi tomkranis (CC-BY 4.0), konversi glTF AsoboStudio & scurest.\nModel Pria Bayangan: CesiumMan oleh Cesium (CC-BY 4.0).\nModel dari glTF Sample Assets (Khronos Group).\nMonster lain dibuat prosedural lewat kode.", 22)
	_button(vb, "KEMBALI", func(): _show("menu"))


func _build_brief() -> void:
	var vb := _screen("brief", "LEVEL", 860.0)
	brief_title = vb.get_child(0)
	brief_text = _label(vb, "", 24, Color(0.75, 0.85, 0.8))
	brief_skill = _label(vb, "", 26, Color(1.0, 0.9, 0.4))
	_label(vb, "Kiri layar: joystick  |  Kanan layar: geser untuk melihat\nTombol bulat kanan bawah: skill  |  Kumpulkan SEMUA shard untuk menang", 20, Color(0.6, 0.7, 0.66))
	_button(vb, "MULAI", func(): start_level(cur_level))
	_button(vb, "KEMBALI", func(): _show("select"))


func _open_brief(i: int) -> void:
	cur_level = i
	var L: Dictionary = Levels.LEVELS[i]
	brief_title.text = "LEVEL %d  -  %s" % [i + 1, String(L.name).to_upper()]
	brief_text.text = "%s\nMonster: %s\nShard: %d" % [L.sub, L.ent_name, L.shards]
	if i == 5:
		brief_skill.text = "UPGRADE: semua skill lebih lama aktif dan lebih cepat pulih (cooldown -40%)."
	else:
		var sd: Dictionary = Levels.SKILLS[Levels.ORDER[i]]
		brief_skill.text = "SKILL BARU: %s\n%s" % [String(sd.name).to_upper(), sd.desc]
	_show("brief")


func _build_result() -> void:
	var vb := _screen("result", "HASIL", 760.0)
	res_title = vb.get_child(0)
	res_text = _label(vb, "", 26)
	res_next = _button(vb, "LEVEL BERIKUTNYA", func(): _open_brief(mini(cur_level + 1, 5)))
	_button(vb, "ULANGI LEVEL", func(): start_level(cur_level))
	_button(vb, "MENU UTAMA", func(): _show("menu"))


func _build_pause() -> void:
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 20
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_layer.visible = false
	add_child(pause_layer)
	var root := Control.new()
	root.theme = th
	pause_layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	root.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(560, 0)
	cc.add_child(vb)
	_label(vb, "JEDA", 52, Color(0.4, 1.0, 0.55))
	_button(vb, "LANJUTKAN", func(): _on_resume())
	_button(vb, "ULANGI LEVEL", func(): _on_resume(); start_level(cur_level))
	_button(vb, "MENU UTAMA", func(): _on_resume(); _end_game(); _show("menu"))


# ------------------------------------------------------------ alur game
func start_level(i: int) -> void:
	cur_level = i
	_end_game()
	get_tree().paused = false
	pause_layer.visible = false
	game = GameScript.new()
	game.setup(i, cfg)
	add_child(game)
	game.level_done.connect(_on_done)
	game.pause_requested.connect(_on_pause)
	_show("")


func _end_game() -> void:
	if game != null:
		game.queue_free()
		game = null


func _on_pause() -> void:
	if game == null or get_tree().paused:
		return
	get_tree().paused = true
	pause_layer.visible = true


func _on_resume() -> void:
	get_tree().paused = false
	pause_layer.visible = false
	if game != null:
		game.hud.reset_touch()


func _on_done(won: bool) -> void:
	var t: float = game.elapsed
	var lives_left: int = game.lives
	_end_game()
	if won:
		if cur_level < 5 and int(cfg["unlocked"]) < cur_level + 2:
			cfg["unlocked"] = cur_level + 2
		_save_cfg()
		var last := cur_level >= 5
		res_title.text = "TAMAT!" if last else "LEVEL SELESAI"
		res_text.text = "Waktu: %d:%02d   |   Nyawa tersisa: %d" % [int(t) / 60, int(t) % 60, lives_left]
		if last:
			res_text.text += "\nKamu mengalahkan kegelapan dan mengumpulkan semua shard."
		res_next.visible = not last
	else:
		res_title.text = "GAME OVER"
		res_text.text = "Monster menangkapmu. Coba lagi!"
		res_next.visible = false
	_show("result")
