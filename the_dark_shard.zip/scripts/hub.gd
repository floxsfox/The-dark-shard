extends Node3D
# Lobi: ruangan bundar dengan 6 portal (satu per level) dan patung di tengah untuk membeli skill.

signal portal_entered(i: int)
signal shop_requested
signal pause_requested

const Lib = preload("res://scripts/lib.gd")
const Ent = preload("res://scripts/entities.gd")
const Levels = preload("res://scripts/levels.gd")
const HudScript = preload("res://scripts/hud.gd")

const ROOM_R := 16.0
const PORTAL_R := 11.0
const STATUE_R := 2.2
const START_POS := Vector3(0, 0, 8.0)

const PORTAL_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled, blend_add, depth_draw_never;
uniform vec3 col : source_color = vec3(0.3, 1.0, 0.5);
uniform float locked = 0.0;
void fragment() {
	vec2 p = UV * 2.0 - vec2(1.0, 1.0);
	float r = length(p);
	if (r > 1.0) {
		discard;
	}
	float a = atan(p.y, p.x);
	float sw = 0.5 + 0.5 * sin(a * 3.0 + r * 11.0 - TIME * 2.5);
	float edge = 1.0 - smoothstep(0.65, 1.0, r);
	vec3 c = col * (0.35 + 0.65 * sw) * edge;
	c = mix(c, vec3(0.12, 0.12, 0.12) * edge, locked * 0.8);
	ALBEDO = c;
	ALPHA = (0.45 + 0.5 * sw) * edge;
}
"""

const PORTAL_COLORS = [
	Color(0.2, 1.0, 0.4), Color(1.0, 0.6, 0.2), Color(0.4, 0.8, 1.0),
	Color(0.85, 1.0, 0.3), Color(0.75, 0.3, 1.0), Color(1.0, 0.15, 0.15),
]

var cfg: Dictionary = {}
var cam: Camera3D
var hud
var pos := START_POS
var yaw := 0.0
var pitch := 0.0
var bob_t := 0.0
var moving := false
var step_acc := 0.0
var t := 0.0
var cool := 1.0
var portals: Array = []
var crystal: MeshInstance3D
var players: Array = []
var play_i := 0
var step_snd: AudioStreamWAV


func setup(config: Dictionary) -> void:
	cfg = config


func _ready() -> void:
	Lib.clear_cache()
	_build_env()
	_build_room()
	_build_statue()
	for i in 6:
		_build_portal(i)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 150.0
	add_child(cam)
	cam.current = true
	var glow := OmniLight3D.new()
	glow.omni_range = 8.0
	glow.light_energy = 0.5
	glow.light_color = Color(0.8, 0.85, 1.0)
	cam.add_child(glow)
	var layer := CanvasLayer.new()
	layer.layer = 2
	add_child(layer)
	hud = HudScript.new()
	layer.add_child(hud)
	hud.hub = true
	hud.level_name = "LOBI"
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	step_snd = Lib.synth(110.0, 55.0, 0.1, 0.45, 0.7, 3.0)
	var dp := AudioStreamPlayer.new()
	dp.stream = Lib.drone()
	dp.volume_db = -12.0
	add_child(dp)
	dp.play()
	hud.toast_show("LOBI  -  masuki portal untuk bermain, dekati patung untuk membeli skill", 4.5)
	refresh()


func reset_player() -> void:
	pos = Vector3(0, 0, 6.0)
	yaw = 0.0
	cool = 1.0
	if hud != null:
		hud.reset_touch()


func refresh() -> void:
	var unlocked: int = int(cfg.get("unlocked", 1))
	for i in 6:
		var pd: Dictionary = portals[i]
		var open: bool = i < unlocked
		pd.mat.set_shader_parameter("locked", 0.0 if open else 1.0)
		var L: Dictionary = Levels.LEVELS[i]
		pd.label.text = "LEVEL %d\n%s%s" % [i + 1, L.name, "" if open else "\n[TERKUNCI]"]
		pd.label.modulate = Color(1, 1, 1) if open else Color(0.55, 0.55, 0.55)
		pd.light.light_energy = 1.6 if open else 0.2


func _build_env() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Lib.make_sky(Levels.EXTRA[0].sky)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.3, 0.32, 0.45)
	env.ambient_light_energy = 0.7
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.fog_enabled = true
	env.fog_light_color = Color(0.04, 0.06, 0.1)
	env.fog_density = 0.012
	env.fog_sky_affect = 0.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var moon := DirectionalLight3D.new()
	moon.light_color = Color(0.6, 0.7, 1.0)
	moon.light_energy = 0.5
	moon.rotation_degrees = Vector3(-50, 30, 0)
	add_child(moon)


func _build_room() -> void:
	var floor_mat: StandardMaterial3D = Lib.make_mat("marble", Color(0.6, 0.55, 0.65), 0.2, true, Color(0.05, 0.04, 0.07), Color(0.22, 0.17, 0.28), 0.35)
	var fl := CylinderMesh.new()
	fl.top_radius = ROOM_R + 1.5
	fl.bottom_radius = ROOM_R + 1.5
	fl.height = 0.4
	fl.radial_segments = 48
	fl.rings = 1
	var fi := MeshInstance3D.new()
	fi.mesh = fl
	fi.material_override = floor_mat
	fi.position = Vector3(0, -0.2, 0)
	add_child(fi)
	# cincin & jalur cahaya dari patung ke tiap portal
	var ring := TorusMesh.new()
	ring.inner_radius = 4.8
	ring.outer_radius = 5.0
	var rm := Ent.mat(Color(0.1, 0.05, 0.2), 2.5, Color(0.6, 0.3, 1.0), 0.3)
	Ent.add(self, ring, rm, Vector3(0, 0.03, 0))
	for i in 6:
		var ang: float = -PI * 0.5 + i * TAU / 6.0
		var d := Vector3(cos(ang), 0.0, sin(ang))
		var seg: float = PORTAL_R - 5.5
		var mid: Vector3 = d * (5.5 + seg * 0.5 - 0.5)
		var col: Color = PORTAL_COLORS[i]
		Ent.add(self, Ent.box(0.14, 0.03, seg), Ent.mat(col * 0.3, 2.0, col, 0.3), Vector3(mid.x, 0.03, mid.z), Vector3(0, atan2(d.x, d.z), 0))
	# tiang melingkar di tepi ruangan
	var pillars: Array = []
	var torches: Array = []
	for i in 24:
		var a: float = i * TAU / 24.0
		var p := Vector3(cos(a) * (ROOM_R + 0.6), 0.0, sin(a) * (ROOM_R + 0.6))
		pillars.append(Transform3D(Basis(), p))
		torches.append(Transform3D(Basis(), p + Vector3(0, 6.3, 0)))
	_multi(Ent.cyl(0.6, 6.0, 12), Ent.mat(Color(0.25, 0.22, 0.3), 0.0, Color(0, 0, 0), 0.5), pillars, Vector3(0, 3.0, 0))
	_multi(Ent.sph(0.25, 8), Ent.glow(Color(1.0, 0.65, 0.25)), torches, Vector3.ZERO)


func _multi(mesh: Mesh, m: Material, xfs: Array, offset: Vector3) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xfs.size()
	for i in xfs.size():
		var xf: Transform3D = xfs[i]
		mm.set_instance_transform(i, Transform3D(xf.basis, xf.origin + offset))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = m
	add_child(mi)


func _build_statue() -> void:
	var n := Node3D.new()
	add_child(n)
	var stone := Ent.mat(Color(0.33, 0.33, 0.4), 0.0, Color(0, 0, 0), 0.6)
	var robe := Ent.mat(Color(0.12, 0.08, 0.2), 0.0, Color(0, 0, 0), 0.7)
	Ent.add(n, Ent.cyl(1.8, 0.5, 20), stone, Vector3(0, 0.25, 0))
	Ent.add(n, Ent.cyl(1.25, 0.5, 20), stone, Vector3(0, 0.75, 0))
	Ent.add(n, Ent.cone(0.9, 2.6, 14), robe, Vector3(0, 2.3, 0))
	Ent.add(n, Ent.sph(0.3, 12), stone, Vector3(0, 3.75, 0))
	Ent.add(n, Ent.cone(0.4, 0.7, 10), robe, Vector3(0, 4.05, 0))
	for s in [-1.0, 1.0]:
		Ent.add(n, Ent.cap(0.12, 1.5), robe, Vector3(s * 0.7, 3.3, 0.0), Vector3(0, 0, s * 0.75))
	var cm := Ent.mat(Color(0.1, 0.4, 0.45), 3.0, Color(0.3, 1.0, 0.9), 0.2)
	crystal = Ent.add(n, Ent.octa(), cm, Vector3(0, 5.2, 0), Vector3.ZERO, Vector3(0.7, 1.2, 0.7))
	var lt := OmniLight3D.new()
	lt.position = Vector3(0, 4.6, 0)
	lt.omni_range = 14.0
	lt.light_energy = 2.0
	lt.light_color = Color(0.4, 1.0, 0.9)
	n.add_child(lt)
	var lb := Label3D.new()
	lb.text = "PATUNG SKILL"
	lb.font_size = 72
	lb.pixel_size = 0.012
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.outline_size = 14
	lb.position = Vector3(0, 6.6, 0)
	lb.modulate = Color(0.6, 1.0, 0.9)
	n.add_child(lb)


func _build_portal(i: int) -> void:
	var ang: float = -PI * 0.5 + i * TAU / 6.0
	var dir := Vector3(cos(ang), 0.0, sin(ang))
	var col: Color = PORTAL_COLORS[i]
	var n := Node3D.new()
	n.position = dir * PORTAL_R
	n.rotation.y = atan2(-dir.x, -dir.z)
	add_child(n)
	var dark := Ent.mat(Color(0.06, 0.06, 0.08), 0.0, Color(0, 0, 0), 0.5)
	Ent.add(n, Ent.box(4.6, 0.3, 1.4), dark, Vector3(0, 0.15, 0))
	var tm := TorusMesh.new()
	tm.inner_radius = 1.6
	tm.outer_radius = 1.9
	Ent.add(n, tm, Ent.mat(col * 0.4, 2.5, col, 0.3), Vector3(0, 2.1, 0), Vector3(PI * 0.5, 0, 0))
	var sh := Shader.new()
	sh.code = PORTAL_SHADER
	var sm := ShaderMaterial.new()
	sm.shader = sh
	sm.set_shader_parameter("col", col)
	var qm := QuadMesh.new()
	qm.size = Vector2(3.5, 3.5)
	var q := MeshInstance3D.new()
	q.mesh = qm
	q.material_override = sm
	q.position = Vector3(0, 2.1, 0)
	n.add_child(q)
	var lt := OmniLight3D.new()
	lt.position = Vector3(0, 2.1, 1.5)
	lt.omni_range = 9.0
	lt.light_energy = 1.6
	lt.light_color = col
	n.add_child(lt)
	var lb := Label3D.new()
	lb.font_size = 56
	lb.pixel_size = 0.011
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.outline_size = 12
	lb.position = Vector3(0, 4.9, 0)
	n.add_child(lb)
	portals.append({"pos": dir * PORTAL_R, "mat": sm, "label": lb, "light": lt})


func play_snd(s, vol: float = 0.0, pitch: float = 1.0) -> void:
	var p: AudioStreamPlayer = players[play_i]
	play_i = (play_i + 1) % players.size()
	p.stream = s
	p.volume_db = vol
	p.pitch_scale = pitch
	p.play()


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	t += delta
	cool = maxf(0.0, cool - delta)
	if hud.pause_flag:
		hud.pause_flag = false
		pause_requested.emit()
	var sens: float = float(cfg.get("sens", 1.0)) * 0.0042
	yaw -= hud.look_accum.x * sens
	pitch = clampf(pitch - hud.look_accum.y * sens, -1.25, 1.25)
	hud.look_accum = Vector2.ZERO
	var mv: Vector2 = hud.move_vec
	var kb := Vector2(float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)), float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
	if kb != Vector2.ZERO:
		mv = kb.normalized()
	if mv.length() < 0.12:
		mv = Vector2.ZERO
	elif mv.length() > 1.0:
		mv = mv.normalized()
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var old: Vector3 = pos
	pos += (right * mv.x - fwd * mv.y) * 5.0 * delta
	# batas ruangan & patung
	var flat := Vector2(pos.x, pos.z)
	if flat.length() > ROOM_R - 0.8:
		flat = flat.normalized() * (ROOM_R - 0.8)
	if flat.length() < STATUE_R:
		flat = flat.normalized() * STATUE_R if flat.length() > 0.01 else Vector2(0, STATUE_R)
	pos = Vector3(flat.x, 0.0, flat.y)
	var d: float = old.distance_to(pos)
	moving = d > 0.001
	if moving:
		bob_t += d * 2.6
		step_acc += d
		if step_acc > 2.1:
			step_acc = 0.0
			play_snd(step_snd, -12.0, randf_range(0.85, 1.15))
	# interaksi patung
	var near_statue: bool = flat.length() < 4.6
	hud.prompt = "BELI SKILL" if near_statue else ""
	hud.wallet = int(cfg.get("wallet", 0))
	if hud.interact_flag:
		hud.interact_flag = false
		if near_statue:
			shop_requested.emit()
	# portal
	if cool <= 0.0:
		var unlocked: int = int(cfg.get("unlocked", 1))
		for i in 6:
			var pp: Vector3 = portals[i].pos
			if Vector2(pos.x - pp.x, pos.z - pp.z).length() < 1.9:
				cool = 1.5
				if i < unlocked:
					portal_entered.emit(i)
				else:
					hud.toast_show("Portal terkunci. Tamatkan level %d dulu." % i, 2.5)
				break
	crystal.rotation.y += delta * 1.2
	crystal.position.y = 5.2 + sin(t * 1.6) * 0.2
	var b: float = sin(bob_t) * 0.04 if moving else 0.0
	cam.position = pos + Vector3(0, 1.62 + b, 0)
	cam.rotation = Vector3(pitch, yaw, 0.0)
