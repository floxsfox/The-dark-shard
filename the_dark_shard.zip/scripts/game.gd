extends Node3D
# Satu level permainan. Dibuat oleh main.gd: game.setup(index, cfg) lalu add_child.

signal level_done(won: bool)
signal pause_requested

const Maze = preload("res://scripts/maze.gd")
const Lib = preload("res://scripts/lib.gd")
const Ent = preload("res://scripts/entities.gd")
const Levels = preload("res://scripts/levels.gd")
const MonsterScript = preload("res://scripts/monster.gd")
const HudScript = preload("res://scripts/hud.gd")

const CH := 8
const BASE_SPEED := 4.7
const RADIUS := 0.38
const START_YAW := -2.356

const SHARD_SHADER := """
shader_type spatial;
render_mode unshaded%s;
uniform vec3 col1 : source_color = vec3(0.05, 0.9, 0.3);
uniform vec3 col2 : source_color = vec3(0.75, 1.0, 0.85);
uniform float boost = 1.0;
void vertex() {
	float ph = MODEL_MATRIX[3].x * 0.7 + MODEL_MATRIX[3].z * 0.9;
	float a = TIME * 1.6 + ph;
	float c = cos(a);
	float s = sin(a);
	vec3 v = VERTEX;
	VERTEX = vec3(v.x * c - v.z * s, v.y + sin(TIME * 2.0 + ph) * 0.07, v.x * s + v.z * c);
}
void fragment() {
	float f = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 1.5);
	ALBEDO = mix(col1, col2, f) * boost;
}
"""

var lvl_idx := 0
var lv: Dictionary = {}
var cfg: Dictionary = {}
var maze
var T: float = 3.0
var wh := 3.4

var wall_mat: StandardMaterial3D
var floor_mat: StandardMaterial3D
var ceil_mat: StandardMaterial3D

var cam: Camera3D
var flash_light: SpotLight3D
var hud
var player_pos := Vector3.ZERO
var start_pos := Vector3.ZERO
var yaw := START_YAW
var pitch := 0.0
var bob_t := 0.0
var moving := false
var step_acc := 0.0
var shake := 0.0
var flick_t := 0.0

var shard_pos := PackedVector3Array()
var shard_n := 0
var shard_total := 0
var shard_mm: MultiMesh
var halo_mm: MultiMesh
var shard_inst: MultiMeshInstance3D
var shard_mat_norm: ShaderMaterial
var shard_mat_det: ShaderMaterial
var halo_mat: StandardMaterial3D
var pick_cd := 0.0

var monsters: Array = []
var dist := PackedInt32Array()
var last_ptile := Vector2i(-999, -999)

var skill_ids: Array = []
var cd_left := {}
var act_left := {}
var upgrade := false
var player_hidden := false
var magnet_on := false
var detector_on := false

var lives := 3
var invuln := 3.0
var frozen := false
var caught_t := 0.0
var caught_by = null
var end_t := -1.0
var end_won := false
var danger := 0.0
var heart_t := 0.0
var beat2_t := -1.0
var elapsed := 0.0
var alert_cd := 0.0
var lamps: Array = []

var players: Array = []
var play_i := 0
var snd := {}
var shard_stream: AudioStream


func setup(idx: int, config: Dictionary) -> void:
	lvl_idx = idx
	cfg = config
	lv = Levels.LEVELS[idx]
	wh = float(lv.wh)
	upgrade = (idx == 5)
	skill_ids = Levels.skills_for(idx)
	for id in skill_ids:
		cd_left[id] = 0.0
		act_left[id] = 0.0


func _ready() -> void:
	T = Maze.TILE
	Lib.clear_cache()
	maze = Maze.new()
	maze.generate(int(lv.cells), int(lv.seed), int(lv.rooms), float(lv.braid))
	dist.resize(maze.W * maze.H)
	dist.fill(-1)
	_build_environment()
	_build_materials()
	_build_geometry()
	_build_props()
	_build_shards()
	_build_player()
	_build_monsters()
	_build_hud()
	_build_audio()
	hud.toast_show("LEVEL %d  -  %s" % [lvl_idx + 1, lv.name], 4.0)


# ---------------------------------------------------------------- dunia
func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = lv.fog
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = lv.ambient
	env.ambient_light_energy = float(lv.amb_e)
	env.fog_enabled = true
	env.fog_light_color = lv.fog
	env.fog_density = float(lv.fog_d)
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	if lv.open:
		var moon := DirectionalLight3D.new()
		moon.light_color = Color(0.5, 0.6, 1.0)
		moon.light_energy = 0.35
		moon.rotation_degrees = Vector3(-55, 35, 0)
		add_child(moon)


func _build_materials() -> void:
	wall_mat = Lib.make_mat(lv.wall, lv.wall_tint, 0.3, true, lv.wall_a, lv.wall_b, 0.85)
	var rep: float = float(CH) * T / 4.0
	floor_mat = Lib.make_mat(lv.floor, lv.floor_tint, rep, false, lv.floor_a, lv.floor_b, 0.8)
	if not lv.open:
		ceil_mat = Lib.make_mat(lv.ceil, lv.ceil_tint, rep, false, lv.wall_a, lv.wall_b, 0.9)


func _scatter(part: Dictionary, xfs: Array) -> void:
	# Sebar mesh sebagai MultiMesh per "chunk" supaya cahaya & culling efisien.
	var groups := {}
	var cs: float = float(CH) * T
	for xf in xfs:
		var k := Vector2i(floori(xf.origin.x / cs), floori(xf.origin.z / cs))
		if not groups.has(k):
			groups[k] = []
		groups[k].append(xf * part.xf)
	for k in groups:
		var arr: Array = groups[k]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = part.mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			mm.set_instance_transform(i, arr[i])
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = part.mat
		add_child(mmi)


func _build_geometry() -> void:
	var walls: Array = []
	for y in range(maze.H):
		for x in range(maze.W):
			if maze.get_t(x, y) != 1:
				continue
			var vis := false
			for k in 4:
				if maze.get_t(x + Maze.DX[k], y + Maze.DY[k]) != 1:
					vis = true
					break
			if vis:
				walls.append(Transform3D(Basis(), Vector3((x + 0.5) * T, 0.0, (y + 0.5) * T)))
	var box := BoxMesh.new()
	box.size = Vector3(T, wh, T)
	_scatter({"mesh": box, "mat": wall_mat, "xf": Transform3D(Basis(), Vector3(0, wh * 0.5, 0))}, walls)
	# lantai & langit-langit per chunk
	var nch: int = ceili(float(maze.W) / float(CH))
	for cy in range(nch):
		for cx in range(nch):
			var has := false
			for y in range(cy * CH, mini((cy + 1) * CH, maze.H)):
				for x in range(cx * CH, mini((cx + 1) * CH, maze.W)):
					if maze.get_t(x, y) != 1:
						has = true
			if not has:
				continue
			var pm := PlaneMesh.new()
			pm.size = Vector2(CH * T, CH * T)
			var c := Vector3((cx + 0.5) * CH * T, 0.0, (cy + 0.5) * CH * T)
			var fl := MeshInstance3D.new()
			fl.mesh = pm
			fl.material_override = floor_mat
			fl.position = c
			add_child(fl)
			if ceil_mat != null:
				var cl := MeshInstance3D.new()
				cl.mesh = pm
				cl.material_override = ceil_mat
				cl.position = c + Vector3(0, wh, 0)
				cl.rotation.x = PI
				add_child(cl)


func _pillar_parts(th: String) -> Array:
	var parts: Array = []
	match th:
		"garden":
			parts.append({"mesh": Ent.cyl(0.24, 2.4, 8), "mat": Ent.mat(Color(0.18, 0.1, 0.05)), "xf": Transform3D(Basis(), Vector3(0, 1.2, 0))})
			parts.append({"mesh": Ent.sph(1.3, 12), "mat": wall_mat, "xf": Transform3D(Basis().scaled(Vector3(1, 0.9, 1)), Vector3(0, 3.0, 0))})
		"mansion":
			var stone := Ent.mat(Color(0.5, 0.46, 0.42), 0.0, Color(0, 0, 0), 0.5)
			parts.append({"mesh": Ent.cyl(0.42, wh, 14), "mat": stone, "xf": Transform3D(Basis(), Vector3(0, wh * 0.5, 0))})
			parts.append({"mesh": Ent.box(1.0, 0.3, 1.0), "mat": stone, "xf": Transform3D(Basis(), Vector3(0, 0.15, 0))})
			parts.append({"mesh": Ent.box(1.0, 0.3, 1.0), "mat": stone, "xf": Transform3D(Basis(), Vector3(0, wh - 0.15, 0))})
		"crypt":
			parts.append({"mesh": Ent.cyl(0.55, wh, 10), "mat": wall_mat, "xf": Transform3D(Basis(), Vector3(0, wh * 0.5, 0))})
			parts.append({"mesh": Ent.sph(0.26, 10), "mat": Ent.mat(Color(0.82, 0.8, 0.72), 0.0, Color(0, 0, 0), 0.6), "xf": Transform3D(Basis(), Vector3(0, 1.7, 0.5))})
		"factory":
			var rust := Ent.mat(Color(0.35, 0.2, 0.12), 0.0, Color(0, 0, 0), 0.6)
			parts.append({"mesh": Ent.cyl(0.36, wh, 10), "mat": rust, "xf": Transform3D(Basis(), Vector3(0, wh * 0.5, 0))})
			parts.append({"mesh": Ent.cyl(0.5, 1.1, 12), "mat": Ent.mat(Color(0.2, 0.25, 0.3), 0.0, Color(0, 0, 0), 0.5), "xf": Transform3D(Basis(), Vector3(0.8, 0.55, 0.4))})
		"cave":
			var cr := Ent.mat(Color(0.3, 0.1, 0.55), 2.5, Color(0.6, 0.2, 1.0), 0.2)
			parts.append({"mesh": Ent.octa(), "mat": cr, "xf": Transform3D(Basis().scaled(Vector3(0.8, 2.6, 0.8)), Vector3(0, 1.3, 0))})
			parts.append({"mesh": Ent.octa(), "mat": cr, "xf": Transform3D(Basis(Vector3(0, 0, 1), 0.4).scaled(Vector3(0.45, 1.4, 0.45)), Vector3(0.6, 0.7, 0.2))})
		"void":
			parts.append({"mesh": Ent.cone(0.7, 3.4, 6), "mat": Ent.mat(Color(0.03, 0.02, 0.04), 0.0, Color(0, 0, 0), 0.2), "xf": Transform3D(Basis(), Vector3(0, 1.7, 0))})
			parts.append({"mesh": Ent.cyl(0.1, wh, 6), "mat": Ent.mat(Color(0.5, 0.0, 0.02), 3.0, Color(1.0, 0.1, 0.1), 0.2), "xf": Transform3D(Basis(), Vector3(0, wh * 0.5, 0))})
	return parts


func _build_center(th: String, tile: Vector2i) -> void:
	var n := Node3D.new()
	n.position = maze.center_of(tile)
	n.rotation.y = maze.rng.randf() * TAU
	add_child(n)
	var lc: Color = lv.lamp
	var none := Color(0, 0, 0)
	match th:
		"garden":
			var st := Ent.mat(Color(0.5, 0.5, 0.47), 0.0, none, 0.6)
			Ent.add(n, Ent.cyl(1.35, 0.55, 20), st, Vector3(0, 0.27, 0))
			Ent.add(n, Ent.cyl(1.15, 0.06, 20), Ent.mat(Color(0.05, 0.25, 0.35), 1.0, Color(0.1, 0.5, 0.8), 0.05), Vector3(0, 0.52, 0))
			Ent.add(n, Ent.cyl(0.17, 1.9, 10), st, Vector3(0, 0.95, 0))
			Ent.add(n, Ent.sph(0.32, 10), st, Vector3(0, 2.0, 0))
			lc = Color(0.4, 0.8, 1.0)
		"mansion":
			var wd := Ent.mat(Color(0.25, 0.13, 0.07), 0.0, none, 0.5)
			Ent.add(n, Ent.box(2.4, 0.12, 1.1), wd, Vector3(0, 0.85, 0))
			for sx in [-1.0, 1.0]:
				for sz in [-1.0, 1.0]:
					Ent.add(n, Ent.box(0.12, 0.85, 0.12), wd, Vector3(sx * 1.1, 0.42, sz * 0.45))
			Ent.add(n, Ent.cyl(0.05, 0.35, 8), Ent.mat(Color(0.9, 0.85, 0.7)), Vector3(0, 1.1, 0))
			Ent.add(n, Ent.sph(0.07, 8), Ent.glow(Color(1, 0.7, 0.2)), Vector3(0, 1.33, 0))
		"crypt":
			var st2 := Ent.mat(Color(0.3, 0.3, 0.3), 0.0, none, 0.8)
			Ent.add(n, Ent.box(2.3, 0.8, 1.1), st2, Vector3(0, 0.4, 0))
			Ent.add(n, Ent.box(2.45, 0.18, 1.25), st2, Vector3(0, 0.88, 0))
			for sx in [-1.0, 1.0]:
				Ent.add(n, Ent.cyl(0.06, 0.4, 8), Ent.mat(Color(0.9, 0.85, 0.7)), Vector3(sx * 1.0, 1.15, 0))
				Ent.add(n, Ent.sph(0.08, 8), Ent.glow(Color(1, 0.6, 0.2)), Vector3(sx * 1.0, 1.42, 0))
		"factory":
			var rust := Ent.mat(Color(0.35, 0.2, 0.12), 0.0, none, 0.6)
			Ent.add(n, Ent.box(1.5, 1.2, 1.5), rust, Vector3(0, 0.6, 0))
			Ent.add(n, Ent.box(1.0, 0.9, 1.0), Ent.mat(Color(0.3, 0.3, 0.2), 0.0, none, 0.6), Vector3(0.2, 1.65, 0.1), Vector3(0, 0.5, 0))
			Ent.add(n, Ent.cyl(0.4, 1.0, 12), rust, Vector3(1.0, 0.5, -0.8))
		"cave":
			var cr := Ent.mat(Color(0.3, 0.1, 0.55), 2.5, Color(0.6, 0.2, 1.0), 0.2)
			Ent.add(n, Ent.octa(), cr, Vector3(0, 1.3, 0), Vector3(0, 0, 0.1), Vector3(0.9, 2.8, 0.9))
			Ent.add(n, Ent.octa(), cr, Vector3(0.7, 0.7, 0.3), Vector3(0, 0, -0.5), Vector3(0.5, 1.5, 0.5))
			Ent.add(n, Ent.octa(), cr, Vector3(-0.6, 0.6, -0.3), Vector3(0.3, 0, 0.5), Vector3(0.5, 1.3, 0.5))
		"void":
			var rd := Ent.mat(Color(0.5, 0.0, 0.02), 3.0, Color(1.0, 0.1, 0.1), 0.2)
			Ent.add(n, Ent.octa(), rd, Vector3(0, 1.7, 0), Vector3.ZERO, Vector3(1.1, 2.2, 1.1))
			Ent.add(n, Ent.cyl(1.1, 0.3, 6), Ent.mat(Color(0.03, 0.02, 0.04), 0.0, none, 0.2), Vector3(0, 0.15, 0))
	var lt := OmniLight3D.new()
	lt.position = Vector3(0, 2.2, 0)
	lt.omni_range = 10.0
	lt.light_energy = 1.6
	lt.light_color = lc
	n.add_child(lt)


func _build_props() -> void:
	var th: String = lv.theme
	var centers := {}
	for r in maze.rooms:
		if r.size.x >= 7 and r.size.y >= 7:
			centers[Vector2i(r.position.x + r.size.x / 2, r.position.y + r.size.y / 2)] = true
	var pillars: Array = []
	for y in range(maze.H):
		for x in range(maze.W):
			if maze.get_t(x, y) == 2 and not centers.has(Vector2i(x, y)):
				pillars.append(Transform3D(Basis(Vector3.UP, maze.rng.randf() * TAU), maze.center_of(Vector2i(x, y))))
	for part in _pillar_parts(th):
		_scatter(part, pillars)
	for t in centers:
		_build_center(th, t)
	# lampu/obor di dinding
	var posts: Array = []
	var bulbs: Array = []
	for s in maze.pick_spaced(8):
		var d: Vector2i = s.d
		var base: Vector3 = maze.center_of(s.t) + Vector3(d.x, 0.0, d.y) * 1.2
		posts.append(Transform3D(Basis(), base))
		var bp: Vector3 = base + Vector3(-d.x * 0.35, 2.4, -d.y * 0.35)
		bulbs.append(Transform3D(Basis(), bp))
		var lt := OmniLight3D.new()
		lt.position = bp
		lt.omni_range = 11.0
		lt.light_energy = 1.5
		lt.light_color = lv.lamp
		add_child(lt)
		lamps.append({"l": lt, "e": 1.5, "ph": maze.rng.randf() * 10.0})
	_scatter({"mesh": Ent.cyl(0.07, 2.4, 6), "mat": Ent.mat(Color(0.05, 0.05, 0.05)), "xf": Transform3D(Basis(), Vector3(0, 1.2, 0))}, posts)
	_scatter({"mesh": Ent.sph(0.17, 8), "mat": Ent.glow(lv.lamp), "xf": Transform3D()}, bulbs)


# ---------------------------------------------------------------- shard
func _shard_material(depth_off: bool) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = SHARD_SHADER % (", depth_test_disabled, fog_disabled" if depth_off else "")
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("boost", 1.6 if depth_off else 1.0)
	return m


func _write_shard(i: int) -> void:
	var p: Vector3 = shard_pos[i]
	shard_mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(0.45, 0.85, 0.45)), p))
	halo_mm.set_instance_transform(i, Transform3D(Basis(), p))


func _build_shards() -> void:
	var tiles: Array = maze.pick_shards(int(lv.shards))
	shard_total = tiles.size()
	shard_n = shard_total
	shard_pos.resize(shard_total)
	for i in shard_total:
		var c: Vector3 = maze.center_of(tiles[i])
		shard_pos[i] = Vector3(c.x + maze.rng.randf_range(-0.5, 0.5), 1.05, c.z + maze.rng.randf_range(-0.5, 0.5))
	var sm := Ent.octa()
	shard_mm = MultiMesh.new()
	shard_mm.transform_format = MultiMesh.TRANSFORM_3D
	shard_mm.mesh = sm
	shard_mm.instance_count = shard_total
	var qm := QuadMesh.new()
	qm.size = Vector2(1.7, 1.7)
	halo_mm = MultiMesh.new()
	halo_mm.transform_format = MultiMesh.TRANSFORM_3D
	halo_mm.mesh = qm
	halo_mm.instance_count = shard_total
	for i in shard_total:
		_write_shard(i)
	shard_mat_norm = _shard_material(false)
	shard_mat_det = _shard_material(true)
	shard_inst = MultiMeshInstance3D.new()
	shard_inst.multimesh = shard_mm
	shard_inst.material_override = shard_mat_norm
	add_child(shard_inst)
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.9))
	g.set_color(1, Color(1, 1, 1, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	halo_mat = StandardMaterial3D.new()
	halo_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	halo_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	halo_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	halo_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	halo_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	halo_mat.albedo_texture = gt
	halo_mat.albedo_color = Color(0.2, 1.0, 0.4, 0.5)
	var hi := MultiMeshInstance3D.new()
	hi.multimesh = halo_mm
	hi.material_override = halo_mat
	add_child(hi)


# ---------------------------------------------------------------- pemain, monster, hud, audio
func _build_player() -> void:
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 120.0
	add_child(cam)
	cam.current = true
	flash_light = SpotLight3D.new()
	flash_light.spot_range = 26.0
	flash_light.spot_angle = 34.0
	flash_light.spot_attenuation = 0.7
	flash_light.light_energy = 4.0
	flash_light.light_color = Color(1.0, 0.95, 0.85)
	flash_light.shadow_enabled = bool(cfg.get("shadows", true))
	cam.add_child(flash_light)
	var glow := OmniLight3D.new()
	glow.omni_range = 7.0
	glow.light_energy = 0.6
	glow.light_color = Color(0.7, 0.8, 1.0)
	cam.add_child(glow)
	start_pos = maze.center_of(maze.start_tile)
	player_pos = start_pos
	cam.position = start_pos + Vector3(0, 1.62, 0)


func _build_monsters() -> void:
	var cands: Array = maze.far_tiles(22 if maze.W > 40 else 18)
	var chosen: Array = []
	for t in cands:
		if chosen.size() >= int(lv.monsters):
			break
		var ok := true
		for c in chosen:
			if maxi(absi(c.x - t.x), absi(c.y - t.y)) < 8:
				ok = false
				break
		if ok:
			chosen.append(t)
	var ents: Array = lv.ents
	for i in chosen.size():
		var m = MonsterScript.new()
		add_child(m)
		m.setup(self, maze, chosen[i], ents[i % ents.size()], lv, i)
		monsters.append(m)


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 2
	add_child(layer)
	hud = HudScript.new()
	layer.add_child(hud)
	hud.level_name = "LEVEL %d  -  %s" % [lvl_idx + 1, lv.name]
	hud.shards_total = shard_total
	hud.shards_left = shard_n


func _build_audio() -> void:
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	shard_stream = load("res://assets/audio/shard_sfx.mp3")
	snd["step"] = Lib.synth(110.0, 55.0, 0.1, 0.45, 0.7, 3.0)
	snd["beat"] = Lib.synth(70.0, 38.0, 0.2, 0.95, 0.05, 3.5)
	snd["speed"] = Lib.synth(300.0, 900.0, 0.35, 0.5, 0.0, 2.0)
	snd["flicker"] = Lib.synth(1300.0, 200.0, 0.25, 0.5, 0.2, 2.0)
	snd["magnet"] = Lib.synth(200.0, 520.0, 0.6, 0.5, 0.0, 1.5)
	snd["detector"] = Lib.synth(660.0, 660.0, 0.6, 0.45, 0.0, 1.2)
	snd["stun"] = Lib.synth(900.0, 90.0, 0.55, 0.65, 0.5, 2.0)
	snd["caught"] = Lib.synth(190.0, 40.0, 1.0, 1.0, 0.55, 1.5)
	snd["screech"] = Lib.synth(1900.0, 800.0, 0.6, 0.55, 0.3, 1.5)
	snd["alert"] = Lib.synth(520.0, 240.0, 0.45, 0.6, 0.3, 2.0)
	snd["win"] = Lib.synth(400.0, 1300.0, 0.9, 0.6, 0.0, 1.2)
	var dp := AudioStreamPlayer.new()
	dp.stream = Lib.drone()
	dp.volume_db = -14.0
	add_child(dp)
	dp.play()


func play_snd(s, vol: float = 0.0, pitch: float = 1.0) -> void:
	if s == null or players.is_empty():
		return
	var p: AudioStreamPlayer = players[play_i]
	play_i = (play_i + 1) % players.size()
	p.stream = s
	p.volume_db = vol
	p.pitch_scale = pitch
	p.play()


# ---------------------------------------------------------------- loop utama
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	elapsed += delta
	alert_cd -= delta
	if end_t >= 0.0:
		end_t -= delta
		if end_t < 0.0:
			set_process(false)
			level_done.emit(end_won)
			return
	if hud.pause_flag:
		hud.pause_flag = false
		pause_requested.emit()
	_update_skills(delta)
	if frozen:
		_frozen_update(delta)
	else:
		_player_update(delta)
		_check_caught()
	_update_shards(delta)
	_update_danger(delta)
	_update_hud()
	_update_lamps()
	_update_cam(delta)


func _blocked(p: Vector3) -> bool:
	return maze.solid_world(p.x - RADIUS, p.z - RADIUS) or maze.solid_world(p.x + RADIUS, p.z - RADIUS) \
		or maze.solid_world(p.x - RADIUS, p.z + RADIUS) or maze.solid_world(p.x + RADIUS, p.z + RADIUS)


func _move(v: Vector3) -> void:
	var np: Vector3 = player_pos + Vector3(v.x, 0.0, 0.0)
	if not _blocked(np):
		player_pos = np
	np = player_pos + Vector3(0.0, 0.0, v.z)
	if not _blocked(np):
		player_pos = np


func dist_at(t: Vector2i) -> int:
	if t.x < 0 or t.y < 0 or t.x >= maze.W or t.y >= maze.H:
		return -1
	return dist[t.y * maze.W + t.x]


func _player_update(delta: float) -> void:
	invuln = maxf(0.0, invuln - delta)
	var sens: float = float(cfg.get("sens", 1.0)) * 0.0042
	yaw -= hud.look_accum.x * sens
	pitch = clampf(pitch - hud.look_accum.y * sens, -1.25, 1.25)
	hud.look_accum = Vector2.ZERO
	for i in hud.skill_queue:
		use_skill(i)
	hud.skill_queue.clear()
	var mv: Vector2 = hud.move_vec
	var kb := Vector2(float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)), float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
	if kb != Vector2.ZERO:
		mv = kb.normalized()
	if mv.length() < 0.12:
		mv = Vector2.ZERO
	elif mv.length() > 1.0:
		mv = mv.normalized()
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var dir: Vector3 = right * mv.x - fwd * mv.y
	var spd: float = BASE_SPEED * (1.65 if float(act_left.get("speed", 0.0)) > 0.0 else 1.0)
	var old: Vector3 = player_pos
	_move(dir * spd * delta)
	var d: float = old.distance_to(player_pos)
	moving = d > 0.001
	if moving:
		bob_t += d * 2.6
		step_acc += d
		if step_acc > 2.1:
			step_acc = 0.0
			play_snd(snd["step"], -12.0, randf_range(0.85, 1.15))
	var pt: Vector2i = maze.tile_of(player_pos)
	if pt != last_ptile:
		last_ptile = pt
		maze.bfs(pt, 28, dist)


func _check_caught() -> void:
	if invuln > 0.0 or frozen:
		return
	for m in monsters:
		if m.stun_t > 0.0:
			continue
		var dx: float = m.position.x - player_pos.x
		var dz: float = m.position.z - player_pos.z
		if dx * dx + dz * dz < 1.3:
			_caught(m)
			return


func _caught(m) -> void:
	lives -= 1
	frozen = true
	caught_by = m
	caught_t = 1.6
	shake = 0.25
	hud.flash = 1.0
	hud.flash_col = Color(0.7, 0.0, 0.0)
	play_snd(snd["caught"], 2.0)
	play_snd(snd["screech"], -2.0)
	Input.vibrate_handheld(400)


func _frozen_update(delta: float) -> void:
	if end_t >= 0.0:
		return
	if caught_by != null:
		var dv: Vector3 = caught_by.position - player_pos
		var target: float = atan2(-dv.x, -dv.z)
		yaw = lerp_angle(yaw, target, 1.0 - exp(-12.0 * delta))
		pitch = lerpf(pitch, 0.1, 0.1)
	caught_t -= delta
	shake = maxf(0.0, shake - delta * 0.12)
	if caught_t <= 0.0:
		if lives <= 0:
			end_won = false
			end_t = 0.4
		else:
			_respawn()


func _respawn() -> void:
	player_pos = start_pos
	yaw = START_YAW
	pitch = 0.0
	for m in monsters:
		m.reset()
	frozen = false
	caught_by = null
	shake = 0.0
	invuln = 3.5
	last_ptile = Vector2i(-999, -999)
	hud.toast_show("Nyawa tersisa: %d" % lives, 2.5)


func on_monster_alert(_m) -> void:
	if alert_cd <= 0.0:
		alert_cd = 5.0
		play_snd(snd["alert"], -3.0)


# ---------------------------------------------------------------- skill
func _update_skills(delta: float) -> void:
	for id in skill_ids:
		cd_left[id] = maxf(0.0, float(cd_left[id]) - delta)
		act_left[id] = maxf(0.0, float(act_left[id]) - delta)
	player_hidden = float(act_left.get("flicker", 0.0)) > 0.0
	magnet_on = float(act_left.get("magnet", 0.0)) > 0.0
	var det: bool = float(act_left.get("detector", 0.0)) > 0.0
	if det != detector_on:
		_set_detector(det)


func _set_detector(on: bool) -> void:
	detector_on = on
	shard_inst.material_override = shard_mat_det if on else shard_mat_norm
	halo_mat.no_depth_test = on
	halo_mat.disable_fog = on
	halo_mat.albedo_color = Color(0.3, 1.0, 0.5, 0.9) if on else Color(0.2, 1.0, 0.4, 0.5)
	for m in monsters:
		m.set_reveal(on)


func use_skill(i: int) -> void:
	if i < 0 or i >= skill_ids.size() or frozen or end_t >= 0.0:
		return
	var id: String = skill_ids[i]
	if float(cd_left[id]) > 0.0:
		return
	var S: Dictionary = Levels.SKILLS[id]
	var cdm := 0.6 if upgrade else 1.0
	var dm := 1.3 if upgrade else 1.0
	cd_left[id] = float(S.cd) * cdm
	var col: Color = S.color
	var n_st := 0
	match id:
		"speed":
			act_left[id] = float(S.dur) * dm
			play_snd(snd["speed"], -4.0)
		"flicker":
			var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
			var best: Vector3 = player_pos
			var s := 0.5
			while s <= 9.0:
				var cand: Vector3 = player_pos + fwd * s
				if _blocked(cand):
					break
				best = cand
				s += 0.5
			player_pos = best
			last_ptile = Vector2i(-999, -999)
			act_left[id] = float(S.dur) * dm
			play_snd(snd["flicker"], -3.0)
		"magnet":
			act_left[id] = float(S.dur) * dm
			play_snd(snd["magnet"], -4.0)
		"detector":
			act_left[id] = float(S.dur) * dm
			play_snd(snd["detector"], -4.0)
		"stun":
			var rad: float = 11.0 * dm
			for m in monsters:
				var dd := Vector2(m.position.x - player_pos.x, m.position.z - player_pos.z).length()
				if dd < rad:
					m.stun(float(S.dur) * dm)
					n_st += 1
			_shockwave(col, rad)
			play_snd(snd["stun"], -2.0)
	hud.flash = 0.35
	hud.flash_col = col
	var msg: String = String(S.name).to_upper()
	if id == "stun":
		msg += "  (%d monster lumpuh)" % n_st
	hud.toast_show(msg, 1.6)


func _shockwave(col: Color, radius: float) -> void:
	var tm := TorusMesh.new()
	tm.inner_radius = 0.9
	tm.outer_radius = 1.0
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.albedo_color = Color(col.r, col.g, col.b, 0.85)
	mt.cull_mode = BaseMaterial3D.CULL_DISABLED
	var mi := MeshInstance3D.new()
	mi.mesh = tm
	mi.material_override = mt
	mi.position = player_pos + Vector3(0, 0.4, 0)
	mi.scale = Vector3(0.2, 0.2, 0.2)
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(radius, radius, radius), 0.55)
	tw.tween_property(mt, "albedo_color:a", 0.0, 0.55)
	tw.chain().tween_callback(mi.queue_free)


# ---------------------------------------------------------------- shard
func _update_shards(delta: float) -> void:
	pick_cd -= delta
	if frozen or shard_n <= 0:
		return
	var pp: Vector3 = player_pos
	var mr: float = 16.0 * (1.3 if upgrade else 1.0)
	var i := 0
	while i < shard_n:
		var s: Vector3 = shard_pos[i]
		var dx: float = pp.x - s.x
		var dz: float = pp.z - s.z
		var d2: float = dx * dx + dz * dz
		if magnet_on and d2 < mr * mr:
			var dir := Vector3(dx, 1.1 - s.y, dz)
			var dl: float = dir.length()
			if dl > 0.01:
				s += dir / dl * minf(dl, 15.0 * delta)
				shard_pos[i] = s
				_write_shard(i)
				dx = pp.x - s.x
				dz = pp.z - s.z
				d2 = dx * dx + dz * dz
		if d2 < 1.3:
			_collect(i)
			if end_t >= 0.0:
				return
		else:
			i += 1


func _collect(i: int) -> void:
	var last: int = shard_n - 1
	shard_pos[i] = shard_pos[last]
	shard_pos.resize(last)
	shard_n = last
	shard_mm.visible_instance_count = shard_n
	halo_mm.visible_instance_count = shard_n
	if i < shard_n:
		_write_shard(i)
	hud.pulse = 1.0
	if pick_cd <= 0.0:
		play_snd(shard_stream, 0.0, randf_range(0.93, 1.1))
		pick_cd = 0.05
	if shard_n == 0:
		end_won = true
		end_t = 2.2
		frozen = true
		play_snd(snd["win"], 0.0)
		hud.toast_show("SEMUA SHARD TERKUMPUL!", 3.0)


# ---------------------------------------------------------------- efek, hud, kamera
func _update_danger(delta: float) -> void:
	var dmin := 999.0
	for m in monsters:
		if m.stun_t > 0.0:
			continue
		var d: float = Vector2(m.position.x - player_pos.x, m.position.z - player_pos.z).length()
		if m.state == 0:
			d *= 1.8
		dmin = minf(dmin, d)
	var target: float = clampf(1.0 - dmin / 24.0, 0.0, 1.0)
	if frozen:
		target = 1.0
	danger = lerpf(danger, target, 1.0 - exp(-3.0 * delta))
	heart_t -= delta
	if danger > 0.2 and heart_t <= 0.0 and not frozen:
		heart_t = lerpf(1.1, 0.4, danger)
		play_snd(snd["beat"], -6.0 + danger * 4.0)
		beat2_t = 0.2
	if beat2_t > 0.0:
		beat2_t -= delta
		if beat2_t <= 0.0:
			play_snd(snd["beat"], -9.0)


func _update_hud() -> void:
	hud.shards_left = shard_n
	hud.lives = lives
	hud.danger = danger
	var arr: Array = []
	for id in skill_ids:
		var S: Dictionary = Levels.SKILLS[id]
		var mx: float = float(S.cd) * (0.6 if upgrade else 1.0)
		arr.append({"label": S.label, "color": S.color, "frac": 1.0 - float(cd_left[id]) / mx, "active": float(act_left[id]) > 0.0})
	hud.skills = arr
	var st := ""
	if player_hidden:
		st = "TAK TERLIHAT"
	elif detector_on:
		st = "DETEKTOR AKTIF"
	elif magnet_on:
		st = "MAGNET AKTIF"
	elif float(act_left.get("speed", 0.0)) > 0.0:
		st = "KECEPATAN"
	hud.status = st
	if shard_n > 0 and shard_n <= 12:
		var best := 1e9
		var bs := Vector3.ZERO
		for i in shard_n:
			var d2: float = player_pos.distance_squared_to(shard_pos[i])
			if d2 < best:
				best = d2
				bs = shard_pos[i]
		var dv := Vector2(bs.x - player_pos.x, bs.z - player_pos.z)
		var f2 := Vector2(-sin(yaw), -cos(yaw))
		var r2 := Vector2(cos(yaw), -sin(yaw))
		hud.arrow_ang = atan2(dv.dot(r2), dv.dot(f2))
		hud.arrow_on = true
	else:
		hud.arrow_on = false


func _update_lamps() -> void:
	for L in lamps:
		var f: float = 0.85 + 0.15 * sin(elapsed * 9.0 + float(L.ph))
		if sin(elapsed * 2.3 + float(L.ph) * 3.0) > 0.97:
			f *= 0.2
		L.l.light_energy = float(L.e) * f


func _update_cam(delta: float) -> void:
	var b: float = sin(bob_t) * 0.045 if moving and not frozen else 0.0
	var p: Vector3 = player_pos + Vector3(0, 1.62 + b, 0)
	if shake > 0.0:
		p += Vector3(randf() - 0.5, randf() - 0.5, 0.0) * shake
	cam.position = p
	cam.rotation = Vector3(pitch, yaw, 0.0)
	var tf := 75.0
	if frozen and caught_by != null:
		tf = 48.0
	elif float(act_left.get("speed", 0.0)) > 0.0:
		tf = 88.0
	cam.fov = lerpf(cam.fov, tf, 1.0 - exp(-8.0 * delta))
	flick_t -= delta
	if flick_t <= 0.0 and randf() < 0.01:
		flick_t = randf_range(0.05, 0.18)
	var e := 4.0 * (0.92 + 0.08 * sin(elapsed * 17.0))
	if flick_t > 0.0:
		e *= randf_range(0.1, 0.6)
	flash_light.light_energy = e
