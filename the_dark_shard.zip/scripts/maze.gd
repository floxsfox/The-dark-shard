extends RefCounted
# Labirin grid. 0 = lantai, 1 = tembok, 2 = pilar/dekorasi (tidak bisa dilewati)

const TILE = 3.0
const DX = [1, -1, 0, 0]
const DY = [0, 0, 1, -1]

var W := 0
var H := 0
var grid := PackedByteArray()
var rooms: Array = []
var start_tile := Vector2i(3, 3)
var start_dist := PackedInt32Array()
var rng := RandomNumberGenerator.new()
var _q := PackedInt32Array()


func get_t(x: int, y: int) -> int:
	if x < 0 or y < 0 or x >= W or y >= H:
		return 1
	return grid[y * W + x]


func set_t(x: int, y: int, v: int) -> void:
	if x >= 0 and y >= 0 and x < W and y < H:
		grid[y * W + x] = v


func solid_tile(x: int, y: int) -> bool:
	return get_t(x, y) != 0


func solid_world(wx: float, wz: float) -> bool:
	return get_t(floori(wx / TILE), floori(wz / TILE)) != 0


func tile_of(p: Vector3) -> Vector2i:
	return Vector2i(floori(p.x / TILE), floori(p.z / TILE))


func center_of(t: Vector2i) -> Vector3:
	return Vector3((t.x + 0.5) * TILE, 0.0, (t.y + 0.5) * TILE)


func _shuffle(a: Array) -> void:
	for i in range(a.size() - 1, 0, -1):
		var j: int = rng.randi() % (i + 1)
		var tmp = a[i]
		a[i] = a[j]
		a[j] = tmp


func generate(cells: int, seed_val: int, n_rooms: int, braid: float) -> void:
	rng.seed = seed_val
	W = cells * 2 + 1
	H = W
	grid.resize(W * H)
	grid.fill(1)
	_q.resize(W * H)

	# 1) labirin dasar: recursive backtracker (lorong panjang berkelok)
	var stack: Array = [Vector2i(1, 1)]
	set_t(1, 1, 0)
	var dirs = [Vector2i(2, 0), Vector2i(-2, 0), Vector2i(0, 2), Vector2i(0, -2)]
	while stack.size() > 0:
		var c: Vector2i = stack.back()
		var opts: Array = []
		for d in dirs:
			var n: Vector2i = c + d
			if n.x > 0 and n.y > 0 and n.x < W - 1 and n.y < H - 1 and get_t(n.x, n.y) == 1:
				opts.append(d)
		if opts.is_empty():
			stack.pop_back()
		else:
			var d2: Vector2i = opts[rng.randi() % opts.size()]
			var n2: Vector2i = c + d2
			var mid: Vector2i = c + d2 / 2
			set_t(mid.x, mid.y, 0)
			set_t(n2.x, n2.y, 0)
			stack.append(n2)

	# 2) ruang start 5x5
	for yy in range(1, 6):
		for xx in range(1, 6):
			set_t(xx, yy, 0)

	# 3) ruang-ruang besar
	rooms.clear()
	var tries := 0
	var sizes = [5, 7, 7, 9]
	while rooms.size() < n_rooms and tries < 300:
		tries += 1
		var rw: int = sizes[rng.randi() % sizes.size()]
		var rh: int = sizes[rng.randi() % sizes.size()]
		if rw > W - 4 or rh > H - 4:
			continue
		var x0: int = 1 + 2 * rng.randi_range(0, (W - 2 - rw) / 2)
		var y0: int = 1 + 2 * rng.randi_range(0, (H - 2 - rh) / 2)
		var r := Rect2i(x0, y0, rw, rh)
		if r.intersects(Rect2i(0, 0, 9, 9)):
			continue
		var overlap := false
		for o in rooms:
			if r.grow(1).intersects(o):
				overlap = true
				break
		if overlap:
			continue
		for yy in range(y0, y0 + rh):
			for xx in range(x0, x0 + rw):
				set_t(xx, yy, 0)
		rooms.append(r)
		if rw >= 7 and rh >= 7:
			set_t(x0 + rw / 2, y0 + rh / 2, 2)
			if rw >= 9 and rh >= 9:
				set_t(x0 + 2, y0 + 2, 2)
				set_t(x0 + rw - 3, y0 + 2, 2)
				set_t(x0 + 2, y0 + rh - 3, 2)
				set_t(x0 + rw - 3, y0 + rh - 3, 2)

	# 4) buka dinding acak supaya ada jalan memutar (loop)
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) != 1:
				continue
			if x % 2 == 0 and y % 2 == 1:
				if get_t(x - 1, y) == 0 and get_t(x + 1, y) == 0 and rng.randf() < braid:
					set_t(x, y, 0)
			elif x % 2 == 1 and y % 2 == 0:
				if get_t(x, y - 1) == 0 and get_t(x, y + 1) == 0 and rng.randf() < braid:
					set_t(x, y, 0)

	# 5) kurangi jalan buntu
	for y in range(1, H - 1, 2):
		for x in range(1, W - 1, 2):
			if get_t(x, y) != 0:
				continue
			var cnt := 0
			for k in 4:
				if get_t(x + DX[k], y + DY[k]) == 0:
					cnt += 1
			if cnt == 1 and rng.randf() < 0.6:
				var ks = [0, 1, 2, 3]
				_shuffle(ks)
				for k in ks:
					var wx: int = x + DX[k]
					var wy: int = y + DY[k]
					if wx > 0 and wy > 0 and wx < W - 1 and wy < H - 1 and get_t(wx, wy) == 1 and get_t(x + DX[k] * 2, y + DY[k] * 2) == 0:
						set_t(wx, wy, 0)
						break

	start_tile = Vector2i(3, 3)
	start_dist.resize(W * H)
	bfs(start_tile, 100000, start_dist)


func bfs(from: Vector2i, maxd: int, out: PackedInt32Array) -> void:
	out.fill(-1)
	if get_t(from.x, from.y) != 0:
		return
	var qh := 0
	var qt := 0
	var s: int = from.y * W + from.x
	out[s] = 0
	_q[qt] = s
	qt += 1
	while qh < qt:
		var i: int = _q[qh]
		qh += 1
		var d: int = out[i]
		if d >= maxd:
			continue
		var x: int = i % W
		var y: int = i / W
		for k in 4:
			var nx: int = x + DX[k]
			var ny: int = y + DY[k]
			if get_t(nx, ny) == 0:
				var ni: int = ny * W + nx
				if out[ni] < 0:
					out[ni] = d + 1
					_q[qt] = ni
					qt += 1


func far_tiles(min_d: int) -> Array:
	var res: Array = []
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) == 0 and start_dist[y * W + x] >= min_d:
				res.append(Vector2i(x, y))
	_shuffle(res)
	return res


func pick_shards(count: int) -> Array:
	var cand: Array = []
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) == 0 and absi(x - start_tile.x) + absi(y - start_tile.y) > 7:
				cand.append(Vector2i(x, y))
	_shuffle(cand)
	var chosen := PackedByteArray()
	chosen.resize(W * H)
	chosen.fill(0)
	var res: Array = []
	for g in [3, 2, 1]:
		for c in cand:
			if res.size() >= count:
				break
			if chosen[c.y * W + c.x] == 1:
				continue
			var blocked := false
			for oy in range(-(g - 1), g):
				for ox in range(-(g - 1), g):
					var px: int = c.x + ox
					var py: int = c.y + oy
					if px >= 0 and py >= 0 and px < W and py < H and chosen[py * W + px] == 1:
						blocked = true
			if not blocked:
				chosen[c.y * W + c.x] = 1
				res.append(c)
	return res


func pick_spaced(spacing: int) -> Array:
	var cand: Array = []
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) != 0:
				continue
			for k in 4:
				if get_t(x + DX[k], y + DY[k]) == 1:
					cand.append({"t": Vector2i(x, y), "d": Vector2i(DX[k], DY[k])})
					break
	_shuffle(cand)
	var res: Array = [{"t": Vector2i(1, 1), "d": Vector2i(-1, 0)}]
	for c in cand:
		var ok := true
		for r in res:
			if maxi(absi(r.t.x - c.t.x), absi(r.t.y - c.t.y)) < spacing:
				ok = false
				break
		if ok:
			res.append(c)
	return res


# ---------------------------------------------------------------- jaring merah & shard spesial
var nets: Array = []   # {"t": Vector2i, "vert": bool}


func reach_count() -> int:
	bfs(start_tile, 100000, start_dist)
	var c := 0
	for v in start_dist:
		if v >= 0:
			c += 1
	return c


# Jaring (tile bertipe 3) dipasang di lorong yang memutus jalan: area di baliknya baru bisa
# dimasuki setelah jaring dihancurkan dengan skill Speed.
func place_nets(count: int, min_pocket: int) -> void:
	nets.clear()
	var cand: Array = []
	var total := 0
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) != 0:
				continue
			total += 1
			if absi(x - start_tile.x) + absi(y - start_tile.y) < 9:
				continue
			var l: bool = get_t(x - 1, y) == 0
			var r: bool = get_t(x + 1, y) == 0
			var u: bool = get_t(x, y - 1) == 0
			var d: bool = get_t(x, y + 1) == 0
			if l and r and not u and not d:
				cand.append({"t": Vector2i(x, y), "vert": false})
			elif u and d and not l and not r:
				cand.append({"t": Vector2i(x, y), "vert": true})
	_shuffle(cand)
	var base := reach_count()
	var tries := 0
	for c in cand:
		if nets.size() >= count or tries >= 30:
			break
		var near := false
		for n in nets:
			if maxi(absi(n.t.x - c.t.x), absi(n.t.y - c.t.y)) < 6:
				near = true
				break
		if near:
			continue
		tries += 1
		set_t(c.t.x, c.t.y, 3)
		var rc := reach_count()
		var pocket: int = base - rc
		if pocket >= min_pocket and pocket <= int(total * 0.4):
			nets.append(c)
			base = rc
		else:
			set_t(c.t.x, c.t.y, 0)
	reach_count()


# Shard spesial: utamakan area di balik jaring, sisanya di tempat jauh dari start.
func pick_special(count: int, taken: Dictionary) -> Array:
	var pocket: Array = []
	var far: Array = []
	for y in range(1, H - 1):
		for x in range(1, W - 1):
			if get_t(x, y) != 0 or taken.has(Vector2i(x, y)):
				continue
			var d: int = start_dist[y * W + x]
			if d < 0:
				pocket.append(Vector2i(x, y))
			elif d >= 22:
				far.append(Vector2i(x, y))
	_shuffle(pocket)
	_shuffle(far)
	var res: Array = []
	for src in [pocket, far]:
		for c in src:
			if res.size() >= count:
				break
			var ok := true
			for r in res:
				if maxi(absi(r.x - c.x), absi(r.y - c.y)) < 6:
					ok = false
					break
			if ok:
				res.append(c)
	return res
