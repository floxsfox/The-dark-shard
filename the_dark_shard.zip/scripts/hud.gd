extends Control
# HUD + kontrol sentuh multi-jari. Kiri = joystick, kanan = geser untuk melihat,
# kanan bawah = tombol skill, kanan atas = pause. Keyboard: WASD, mouse (klik+geser), 1-5, Esc.

const JOY_R := 95.0
const BTN_R := 52.0

var font: Font
var vig: GradientTexture2D

var move_vec := Vector2.ZERO
var look_accum := Vector2.ZERO
var skill_queue: Array = []
var pause_flag := false

var skills: Array = []
var shards_left := 0
var shards_total := 0
var lives := 3
var level_name := ""
var danger := 0.0
var flash := 0.0
var flash_col := Color(0.7, 0, 0)
var toast := ""
var toast_t := 0.0
var arrow_on := false
var arrow_ang := 0.0
var status := ""
var pulse := 0.0
var hub := false
var wallet := 0
var prompt := ""
var interact_flag := false

var joy_id := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var look_id := -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	font = get_theme_default_font()
	var g := Gradient.new()
	g.set_color(0, Color(1, 0.1, 0.1, 0.0))
	g.set_color(1, Color(1, 0.1, 0.1, 1.0))
	g.set_offset(0, 0.55)
	vig = GradientTexture2D.new()
	vig.gradient = g
	vig.fill = GradientTexture2D.FILL_RADIAL
	vig.fill_from = Vector2(0.5, 0.5)
	vig.fill_to = Vector2(1.0, 0.5)
	vig.width = 128
	vig.height = 128


func toast_show(t: String, secs: float = 2.0) -> void:
	toast = t
	toast_t = secs


func reset_touch() -> void:
	joy_id = -1
	look_id = -1
	move_vec = Vector2.ZERO


func btn_pos(i: int) -> Vector2:
	var offs = [Vector2(-85, -85), Vector2(-205, -70), Vector2(-325, -70), Vector2(-145, -190), Vector2(-265, -190)]
	return size + offs[i]


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var p: Vector2 = event.position
		if event.pressed:
			if p.distance_to(Vector2(size.x - 55.0, 55.0)) < 46.0:
				pause_flag = true
				return
			if prompt != "" and Rect2(size.x * 0.5 - 190.0, size.y - 150.0, 380.0, 90.0).has_point(p):
				interact_flag = true
				return
			for i in skills.size():
				if p.distance_to(btn_pos(i)) < BTN_R + 12.0:
					skill_queue.append(i)
					return
			if p.x < size.x * 0.45 and p.y > 110.0 and joy_id == -1:
				joy_id = event.index
				joy_origin = p
				joy_pos = p
				move_vec = Vector2.ZERO
			elif p.x >= size.x * 0.45 and look_id == -1:
				look_id = event.index
		else:
			if event.index == joy_id:
				joy_id = -1
				move_vec = Vector2.ZERO
			elif event.index == look_id:
				look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joy_id:
			var v: Vector2 = event.position - joy_origin
			if v.length() > JOY_R:
				v = v.normalized() * JOY_R
			joy_pos = joy_origin + v
			move_vec = v / JOY_R
		elif event.index == look_id:
			look_accum += event.relative
	elif event is InputEventMouseMotion:
		if not DisplayServer.is_touchscreen_available():
			if event.button_mask != 0:
				look_accum += event.relative
	elif event is InputEventKey:
		if event.pressed and not event.echo:
			match event.keycode:
				KEY_1:
					skill_queue.append(0)
				KEY_2:
					skill_queue.append(1)
				KEY_3:
					skill_queue.append(2)
				KEY_4:
					skill_queue.append(3)
				KEY_5:
					skill_queue.append(4)
				KEY_E:
					interact_flag = true
				KEY_ESCAPE:
					pause_flag = true


func _process(delta: float) -> void:
	toast_t -= delta
	flash = maxf(0.0, flash - delta * 1.6)
	pulse = maxf(0.0, pulse - delta * 3.0)
	queue_redraw()


func _draw() -> void:
	var S: Vector2 = size
	if danger > 0.03:
		draw_texture_rect(vig, Rect2(Vector2.ZERO, S), false, Color(1, 1, 1, clampf(danger, 0.0, 1.0) * 0.9))
	if flash > 0.01:
		draw_rect(Rect2(Vector2.ZERO, S), Color(flash_col.r, flash_col.g, flash_col.b, flash * 0.6))
	# penghitung shard
	var col_shard := Color(0.45, 1.0, 0.6)
	var sz: int = 30 + int(pulse * 6.0)
	if hub:
		draw_string(font, Vector2(26, 46), "SHARD: %d" % wallet, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, col_shard)
	else:
		draw_string(font, Vector2(26, 46), "SHARD  %d / %d" % [shards_total - shards_left, shards_total], HORIZONTAL_ALIGNMENT_LEFT, -1, sz, col_shard)
		for i in 3:
			var c := Color(0.95, 0.15, 0.2) if i < lives else Color(0.25, 0.08, 0.1)
			draw_circle(Vector2(36 + i * 32, 78), 11.0, c)
	draw_string(font, Vector2(26, 110), level_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.7, 0.8, 0.75, 0.8))
	# tombol interaksi (lobi)
	if prompt != "":
		var br := Rect2(S.x * 0.5 - 190.0, S.y - 150.0, 380.0, 90.0)
		draw_rect(br, Color(0.04, 0.2, 0.12, 0.85))
		draw_rect(br, Color(0.4, 1.0, 0.6, 0.9), false, 3.0)
		draw_string(font, Vector2(br.position.x, br.position.y + 57.0), prompt, HORIZONTAL_ALIGNMENT_CENTER, br.size.x, 32, Color(0.9, 1.0, 0.92))
	# crosshair
	draw_circle(S * 0.5, 2.5, Color(1, 1, 1, 0.35))
	# panah petunjuk shard terakhir
	if arrow_on:
		draw_set_transform(Vector2(S.x * 0.5, 90.0), arrow_ang, Vector2.ONE)
		draw_colored_polygon(PackedVector2Array([Vector2(0, -38), Vector2(24, 20), Vector2(0, 8), Vector2(-24, 20)]), Color(0.4, 1.0, 0.6, 0.85))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# joystick
	if joy_id != -1:
		draw_circle(joy_origin, JOY_R, Color(1, 1, 1, 0.07))
		draw_arc(joy_origin, JOY_R, 0.0, TAU, 40, Color(1, 1, 1, 0.3), 3.0)
		draw_circle(joy_pos, 38.0, Color(1, 1, 1, 0.28))
	else:
		draw_arc(Vector2(150, S.y - 150), JOY_R, 0.0, TAU, 40, Color(1, 1, 1, 0.1), 2.0)
	# tombol skill
	for i in skills.size():
		var sk: Dictionary = skills[i]
		var c: Vector2 = btn_pos(i)
		var col: Color = sk.color
		draw_circle(c, BTN_R, Color(0, 0, 0, 0.55))
		if sk.active:
			draw_circle(c, BTN_R, Color(col.r, col.g, col.b, 0.4))
		var frac: float = clampf(sk.frac, 0.0, 1.0)
		var ring: Color = col if frac >= 1.0 else col.darkened(0.55)
		draw_arc(c, BTN_R - 3.0, -PI * 0.5, -PI * 0.5 + TAU * frac, 48, ring, 6.0)
		draw_string(font, c + Vector2(-BTN_R, 7), sk.label, HORIZONTAL_ALIGNMENT_CENTER, BTN_R * 2.0, 19, Color(1, 1, 1, 0.95 if frac >= 1.0 else 0.5))
		var chg: int = sk.charges
		if chg >= 0:
			draw_circle(c + Vector2(BTN_R * 0.72, -BTN_R * 0.72), 17.0, Color(0, 0, 0, 0.85))
			draw_string(font, c + Vector2(BTN_R * 0.72 - 17.0, -BTN_R * 0.72 + 8.0), "x%d" % chg, HORIZONTAL_ALIGNMENT_CENTER, 34.0, 20, col if chg > 0 else Color(0.6, 0.6, 0.6))
	# tombol pause
	var pc := Vector2(S.x - 55.0, 55.0)
	draw_circle(pc, 34.0, Color(0, 0, 0, 0.45))
	draw_rect(Rect2(pc + Vector2(-10, -12), Vector2(7, 24)), Color(1, 1, 1, 0.8))
	draw_rect(Rect2(pc + Vector2(3, -12), Vector2(7, 24)), Color(1, 1, 1, 0.8))
	# toast & status
	if toast_t > 0.0:
		draw_string(font, Vector2(0, S.y * 0.3), toast, HORIZONTAL_ALIGNMENT_CENTER, S.x, 36, Color(1, 1, 1, clampf(toast_t, 0.0, 1.0)))
	if status != "":
		draw_string(font, Vector2(0, S.y - 28), status, HORIZONTAL_ALIGNMENT_CENTER, S.x, 22, Color(0.8, 1.0, 0.85, 0.85))
