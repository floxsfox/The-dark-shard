# The Dark Shard (Godot 4.3)

Game horor labirin 3D ala Dark Deception. 6 level, 6 map berbeda, kumpulkan semua shard hijau.

## Skill
Level 1 Speed, Level 2 Flicker, Level 3 Magnet, Level 4 Detector, Level 5 Pelumpuh, Level 6 upgrade semua skill.

## Build APK dari HP (GitHub web)
1. Upload `the_dark_shard.zip` ke root repo (Add file > Upload files).
2. Add file > Create new file, nama `.github/workflows/build-apk.yml`, tempel isi file YML.
3. Tab Actions > "Build APK - The Dark Shard" > Run workflow.
4. Setelah hijau, unduh `TheDarkShard.apk` dari Releases (atau Artifacts).

## Mengubah isi game
- `scripts/levels.gd` : ukuran map, jumlah shard/monster, kecepatan, warna, skill.
- `tools/textures.txt` : daftar texture ambientCG (CC0).
- `tools/models.txt` : URL model .glb untuk monster (entity_1.glb ... entity_N.glb).
