# The Dark Shard (Godot 4.3)

Game horor labirin 3D ala Dark Deception. 6 level, 6 map berbeda.

## Alur game
Menu -> MAIN -> **Lobi** (ruangan bundar, 6 portal, patung di tengah).
- Masuki portal untuk bermain level (level terkunci sampai level sebelumnya tamat).
- Dekati patung -> tombol BELI SKILL. Mata uang = shard yang dikumpulkan di level.
- Speed gratis. Flicker 90, Magnet 110, Detector 130, Pelumpuh 150 shard.

## Di dalam level
- Tablet hitam di tangan kiri = peta (garis putih). Hijau = shard, biru = kamu, merah = monster (muncul saat Detector aktif).
- Jaring merah menghalangi jalan. Hancurkan dengan menabraknya saat skill Speed aktif.
- Detector butuh SHARD MERAH, Pelumpuh butuh SHARD EMAS (cari di level, ada berkas cahaya di atas tembok).
- 1 level = 1 soundtrack, diacak tiap game dibuka (assets/audio/ost_1..3.mp3).

## Build APK dari HP (GitHub web)
1. Upload `the_dark_shard.zip` ke root repo (Add file > Upload files).
2. Add file > Create new file, nama `.github/workflows/build-apk.yml`, tempel isi file YML.
3. Tab Actions > "Build APK - The Dark Shard" > Run workflow.
4. Setelah hijau, unduh `TheDarkShard.apk` dari Releases (atau Artifacts).

## Mengubah isi game
- `scripts/levels.gd` : harga skill, jumlah jaring/shard spesial, ukuran map, monster, warna, langit.
- `tools/textures.txt` : daftar texture ambientCG (CC0).
- `tools/models.txt` : URL model .glb untuk monster.
