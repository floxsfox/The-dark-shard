#!/usr/bin/env bash
# Mengunduh texture CC0 (ambientCG) dan model. Semua bersifat opsional:
# kalau gagal, game otomatis memakai texture/monster buatan kode.
set +e
cd "$(dirname "$0")/.."
TEX=assets/textures
MOD=assets/models
TMP=$(mktemp -d)
UA="Mozilla/5.0 (X11; Linux x86_64) DarkShardBuild"
mkdir -p "$TEX" "$MOD"

try_id() {   # $1 nama_lokal  $2 id ambientCG
  local z="$TMP/$2.zip" d="$TMP/$2"
  curl -fsSL -A "$UA" --retry 2 -o "$z" "https://ambientcg.com/get?file=$2_1K-JPG.zip" || return 1
  unzip -tq "$z" >/dev/null 2>&1 || return 1
  rm -rf "$d"; mkdir -p "$d"; unzip -q -o "$z" -d "$d"
  local c n r
  c=$(ls "$d"/*_Color.jpg 2>/dev/null | head -n1)
  [ -z "$c" ] && return 1
  cp "$c" "$TEX/$1_color.dat"
  n=$(ls "$d"/*_NormalGL.jpg 2>/dev/null | head -n1); [ -n "$n" ] && cp "$n" "$TEX/$1_normal.dat"
  r=$(ls "$d"/*_Roughness.jpg 2>/dev/null | head -n1); [ -n "$r" ] && cp "$r" "$TEX/$1_rough.dat"
  return 0
}

while IFS='|' read -r name ids query; do
  case "$name" in ""|\#*) continue;; esac
  ok=0
  for id in ${ids//,/ }; do
    if try_id "$name" "$id"; then echo "OK   $name <- $id"; ok=1; break; fi
  done
  if [ $ok = 0 ] && [ -n "$query" ]; then
    q=${query// /%20}
    found=$(curl -fsSL -A "$UA" "https://ambientcg.com/api/v2/full_json?q=$q&type=Material&sort=Popular&limit=8" \
      | grep -oE '"assetId" *: *"[^"]+"' | sed -E 's/.*"([^"]+)"$/\1/')
    for id in $found; do
      if try_id "$name" "$id"; then echo "OK   $name <- $id (hasil cari '$query')"; ok=1; break; fi
    done
  fi
  [ $ok = 0 ] && echo "GAGAL $name (pakai texture buatan kode)"
done < tools/textures.txt

while IFS='|' read -r fname url; do
  case "$fname" in ""|\#*) continue;; esac
  if curl -fsSL -A "$UA" --retry 2 -o "$MOD/$fname" "$url" && [ "$(stat -c %s "$MOD/$fname")" -gt 1000 ]; then
    echo "OK   model $fname"
  else
    rm -f "$MOD/$fname"; echo "GAGAL model $fname (pakai monster buatan kode)"
  fi
done < tools/models.txt

rm -rf "$TMP"
ls -la "$TEX" "$MOD"
exit 0
